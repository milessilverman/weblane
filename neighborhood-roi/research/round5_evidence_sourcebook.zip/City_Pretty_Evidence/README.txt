CITY PRETTY — LA COUNTY EVIDENCE SOURCEBOOK
Verification snapshot: 2 November 2026

START HERE
Open index.html in a browser for all four tables, clickable source links and the full NR register. The HTML document works offline; following a source link requires Internet access.

CONTENTS
- city_pretty_evidence.xlsx: four filterable worksheets, frozen headers/identifying column and source links as full URL text. The Costs sheet includes the three derived calculations as Excel formulas below its main table.
- part_1_eifd_inputs.csv
- part_2_corridor_maps.csv
- part_3_broadband_5g.csv
- part_4_costs.csv
- city_pretty_evidence.json: the same four tables and column names, report notes and NR register.
- unresolved_NR.txt: remaining gaps and suspected nonexistence, explicitly identified as inference.

INTERPRETATION
NR means not recovered, not zero. VERIFIED applies only to the exact stated scope. Links to unreadable ZIP payloads do not establish their internal formats, schemas or example records. Draft plans are distinguished from adopted plans. Approved budgets are distinguished from final expenditure. Publication/approval dates are distinguished from dollar-price bases.

Calculated ratios are whole-project ratios, not standalone trail-paving costs. Annual speed-camera vendor fee is a bundled services amount, not a recovered capital/O&M split.

CSV files use UTF-8 with a BOM and quote all fields. NR values remain text. True identifiers must remain strings, including leading-zero TRA/FIPS/GEOID values. JSON retains numeric standalone values when supplied as numbers.

SCOPE
This export packages the preceding verification response; no new source research was performed. It is a sourcebook, not the City Pretty application, an EIFD financial model or a complete raw GIS/data download. Files whose contents were not recovered have not been fabricated or included as datasets.
