# City Pretty — Part 4: Best funding stacks

Date: 2026-11-02. Sources: `part4_funding.csv` (81 rows: L01–L18, S01–S21, F01–F19, U01–U23).

## How to read the shares

- **REAL (program rule)** = a share, cap, or match stated in a retrieved source for that program (e.g. SS4A 80% federal maximum, TCC 50% leverage). The rule is real; the stack total is not an award.
- **ILLUSTRATIVE** = an invented-looking split used ONLY to show how a stack could be divided. No source supports that exact split. Do not quote an ILLUSTRATIVE split as a program requirement, a typical award, or a promised contribution.
- **Eligibility is the claim, not funding.** Every stack below combines sources whose retrieved eligibility covers the project type. Stacking rules are NR for most rows in the CSV — check the current guideline/NOFA for each source before assuming funds can combine, and check whether one source can be match/leverage for another.
- Amounts, cycles, and statuses are as in `part4_funding.csv`. Several sources below were closed, round-based, or status-NR as of late 2026 (e.g. TCC Round 6 closed 30 Sept 2026; SS4A FY2026 closed 26 May 2026; Urban Greening Round 1 under evaluation Oct 2026). A stack naming a closed round is a template for the next round, not a live application.
- Do not use rows marked DEFUNCT (U18 Neighborly), NONE FOUND (U19 biodiversity credits), or NOT RETRIEVED (F16–F18, S18–S21, U20–U23) in any stack.

---

## 1. Transit, bus priority, and station areas

### 1A. Bus-only lane + bus bulbs + signal priority on a main street
- F02 SS4A Implementation — REAL rule: federal share max 80%, 20% non-federal match (secondary summary of FY2026 NOFO; verify in NOFO).
- L04 Measure M Local Return (17% of Measure M) + L05 Measure R Local Return (15%) + L06 Prop A / L07 Prop C Local Return — formula funds, transportation-only, per-capita. ILLUSTRATIVE remainder after SS4A.
- S11 STPG (planning only) for the corridor plan that precedes construction — REAL rule: 11.47% local match (Sustainable Communities, FY2025-26 listing).
- ILLUSTRATIVE split: SS4A 60% / Local Return (M/R/A/C combined) 30% / city or other local 10%. The 60/30/10 split is ILLUSTRATIVE.

### 1B. Protected bike/pedestrian link to a transit station (with a housing anchor)
- S07 AHSC — STI infrastructure component only, with an affordable-housing development as anchor. Round 9 range $10M–$50M per project (REAL, SGC).
- S04 ATP — bike/pedestrian and Safe Routes to School construction. SB 1 adds $100M/year to ATP (REAL, statute figure).
- L04/L05 Local Return for the local street portion.
- ILLUSTRATIVE split: AHSC STI 50% / ATP 35% / Local Return 15%. ILLUSTRATIVE.

### 1C. Large fixed-guideway / BRT spine with main-street rebuild
- F09 FTA Capital Investment Grants — REAL caps: max CIG share 60% New Starts, 80% Small Starts/Core Capacity (proposed Oct 2026 methodology starting at 40% is PROPOSED only).
- F05 CRP (formula via Caltrans/SCAG) for bike/ped and traffic-management elements — REAL rule in MPO calls: at least 20% non-federal.
- L04 Measure M expenditure-plan categories (not Local Return alone) for the Metro project scope — amount NR.
- ILLUSTRATIVE split: CIG 50% / Metro Measure M project funds 35% / CRP + local 15%. ILLUSTRATIVE; CIG projects take years and require a Medium-or-better FTA rating.

## 2. Bike lanes, pedestrian safety, and school streets

### 2A. High-injury corridor: raised crosswalks, daylighting, lighting, protected lanes
- F02 SS4A (see 1A) — plan + implementation; implementation requires an eligible safety action plan (secondary summary; verify).
- S04 ATP for the bike/ped construction elements.
- L04/L05 Local Return.
- ILLUSTRATIVE split: SS4A 50% / ATP 30% / Local Return 20%. ILLUSTRATIVE.

### 2B. Neighborhood bike/ped plan first, build later
- S11 STPG Sustainable Communities (planning only) — REAL: 11.47% match.
- S04 ATP or F02 SS4A Planning/Demonstration ($100k–$5M, FY2026) for the follow-on plan/demo.
- L17 Development Agreement (only if a large project is in entitlement nearby) for a named, funded segment — negotiated, no standard share.
- ILLUSTRATIVE split: STPG 70% of planning cost / city 30%. ILLUSTRATIVE.

### 2C. Trail / rails-to-trails / creek path segment
- S04 ATP (recreational trails listed as eligible).
- F05 CRP for a bike/ped path that reduces transport CO2.
- L03 Measure A (2016 parks) for trail/open-space elements in a park-need area; S15 RMC where the site is inside RMC jurisdiction and the project is watershed/habitat/public-access work.
- ILLUSTRATIVE split: ATP 45% / CRP 25% / Measure A parks or RMC 20% / local 10%. ILLUSTRATIVE. Check RMC boundary first (S15).

## 3. Street trees, greening, and stormwater (green streets)

### 3A. Green street: shade trees + bioswales + permeable paving + seating
- S08 Urban Greening (CNRA, Prop 4) — Round 1 $46.125M available (2026); 40% intent for vulnerable/disadvantaged-community benefit (2026 cycle). Match NR.
- L01 Measure W Regional Program (50% of SCWP revenue) for the stormwater-capture elements, framed as a multi-benefit project.
- S09 CAL FIRE Urban & Community Forestry for the tree planting/establishment/workforce elements — IRA tranche closed May 2024; Prop 4 $50M total allocation exists but open-cycle status NR.
- ILLUSTRATIVE split: Urban Greening 45% / Measure W Regional 35% / CAL FIRE UCF 20%. ILLUSTRATIVE. Example in the brief ("CAL FIRE 75% + Measure W municipal 15% + in-lieu 10%") is NOT used: no source supports those shares.

### 3B. Street-tree planting at scale in a heat-island corridor
- S09 CAL FIRE UCF (see 3A) + F15 USDA U&CF (IRA) — F15 rescission scope NR; verify funds remain before scoping.
- L14 LAMC tree in-lieu fees (2018 figures $2,612/$1,945/$267 per tree — do NOT cite as current) for planting in the same neighborhood as the paying development, via the Board/Council location process.
- U11 City Forest Credits — REAL registry/protocols verified, but NO price, volume, or LA project verified; revenue only after registry approval and a 26-year commitment. Do not budget a per-tree credit value.
- ILLUSTRATIVE split: CAL FIRE/USDA grants 70% / in-lieu-fee planting 20% / City Forest Credits (future, uncertain) 10%. ILLUSTRATIVE; the credit share is speculative and must not be treated as committed.

### 3C. Stormwater capture park / rain garden on a tax-exempt partner site
- L01 Measure W Regional for multi-benefit stormwater capture.
- U12 Safe, Clean Water Credit Trading (TCTUs) — REAL structure: seller must fund the improvement with non-SCW funds; municipalities excluded as buyers/sellers; same watershed + same municipality. Seller is a tax-exempt owner (school, faith-based, hospital, nonprofit). TCTU = $1 applied to a buyer's assessment; purchased at less than $1 per TCTU. No completed-trade volume verified.
- L02 Measure W Municipal Program — only for the city/county share where the city is the applicant; cannot be the TCTU-generating funds (see U12 exclusion).
- ILLUSTRATIVE split: Measure W Regional 60% / TCTU sale proceeds 25% / partner/philanthropy (U17, no open program verified) 15%. ILLUSTRATIVE. Structure via the exempt partner; a municipal project cannot sell TCTUs itself.

## 4. Parks, culture, and community facilities

### 4A. Pocket park / park-poor neighborhood park
- L03 Measure A (2016 parks) — formula Categories 1–2 + competitive grants; 13% to high/very-high-need study areas.
- S08 Urban Greening for heat-refuge green space with public access.
- S15 RMC (inside jurisdiction) for park-poor new parks / urban tree canopy / public access.
- ILLUSTRATIVE split: Measure A 50% / Urban Greening 30% / RMC 20%. ILLUSTRATIVE.

### 4B. Park building / community center renovation in a low/moderate-income area
- F10 CDBG formula entitlement — must meet a national objective and fit the Consolidated Plan; amount NR for LA.
- F11 Section 108 loan guarantee (debt, not a grant) — up to 5× the most recent CDBG allocation; max 20-year repayment; pledges future CDBG. Use only with a debt-capacity assessment.
- U16 RAP sponsorship/naming (City of LA park assets only; Board approval; no commercial purchase-message signage) for a named amenity, grove, court, or program — negotiated, no rate card.
- ILLUSTRATIVE split: CDBG grant 55% / Section 108 loan 30% / sponsorship + philanthropy 15%. ILLUSTRATIVE; the loan share is debt, not free money.

### 4C. Culture / public art / open-streets programming in and around a park or plaza
- L03 Measure A parks (only the park-improvement elements that fit).
- U17 Philanthropy category — NO open grant program, amount, or deadline verified; foundations named are verified LA givers only. Do not budget until a specific RFP is retrieved.
- U16 RAP sponsorship for events/programs on RAP assets.
- ILLUSTRATIVE split: Measure A 40% / philanthropy 40% / sponsorship 20%. ILLUSTRATIVE and the least secure stack in this file — treat as fundraising targets, not funding.

## 5. Housing-anchored neighborhood improvements

### 5A. Affordable housing + streetscape (transit-adjacent)
- S07 AHSC (housing loan + STI grant + program grants; Round 9 $10M–$50M per project).
- L10 Measure ULA (City of LA only; housing production/preservation) and/or L11 Measure HHH (bond; remaining balance NR — do not assume available) for the housing capital stack.
- L15 AHLF for housing production/preservation — expenditure-plan/litigation status NR beyond July 2026 memo; verify before assuming availability.
- ILLUSTRATIVE split: AHSC 40% / ULA or HHH 35% / AHLF + LIHTC/other housing finance 25%. ILLUSTRATIVE. LIHTC itself is F18 NOT RETRIEVED — do not cite LIHTC terms from this file.

### 5B. Supportive housing with a high-quality courtyard / street frontage
- L11 HHH + L09 Measure A (2024) homelessness/housing funds (60% Comprehensive Homeless Services / 35.75% LACAHSA split is a REAL allocation split in the ordinance summary, not a project stack split).
- S03 Prop 1 (2024) BHCIP only where the project is genuinely a behavioral-health facility or supportive-housing site with eligible facility/site work — general beautification is NR as eligible.
- ILLUSTRATIVE split: HHH 45% / Measure A (2024) 35% / other housing finance 20%. ILLUSTRATIVE.

### 5C. Transit-adjacent mixed-income building delivering public realm by design (no cash grant for the street)
- L16 TOC incentives (density/height/parking relief for on-site affordable units within ½ mile of a Major Transit Stop) — no cash; negotiate ground-floor public realm, courtyard, trees, and active frontage in design. Benefits beyond the set-aside are NOT guaranteed.
- L17 Development Agreement (only for a large vested project) for a named, funded, enforceable public benefit with amount, location, and timing in the agreement.
- L13 Quimby / Park Mitigation fees paid by the development, spent by RAP on park facilities serving new residents ($17,964 subdivision / $8,805 non-subdivision per unit, July 1, 2025 schedule).
- No percentage split: this is value-capture + fee revenue, not a grant stack. Do not present TOC as cash.

## 6. Environment, health, and resilience

### 6A. Brownfield parcel → pocket park / plaza / housing site
- F12 EPA Brownfields MARC — REAL caps (FY2027 anticipated): Assessment $500k, Coalition $1M, RLF $1M, Cleanup $500k; Cleanup/RLF 20% cost share. FY2027 solicitations anticipated fall 2026; no Multipurpose solicitation in FY2027.
- L03 Measure A parks or S15 RMC for the reuse park elements (jurisdiction/eligibility checks apply).
- F10 CDBG for reuse construction in a low/moderate-income area, subject to the Consolidated Plan.
- ILLUSTRATIVE split: Brownfields Cleanup/Assessment 25% / Measure A or RMC 45% / CDBG 30%. ILLUSTRATIVE.

### 6B. Flood / heat / wildfire resilience hub (hardened community building + green street + backup power)
- F13 BRIC — status after the July 2026 combined-round closure is NR; do NOT present as currently open. Long review (median 7–9 months, GAO).
- F14 HMGP — post-disaster only, after a Presidential declaration, in the Hazard Mitigation Plan. REAL rule: 75% federal / 25% non-federal; CDBG is the stated exception usable for the non-federal share.
- S16 CRC Round 2 (approx. $55M, NOFA opened July 2, 2026; deadline/award outcomes NR) for the resilience-center capacity element — verify in the CRC NOFA; do not assume a park/streetscape qualifies alone.
- ILLUSTRATIVE split: BRIC or HMGP 60% / CRC 25% / CDBG match 15%. ILLUSTRATIVE and conditional on a declaration (HMGP) or an open round (BRIC/CRC).

### 6C. Wildland-edge fuel reduction + restoration + trail access (SMMC Zone only)
- S14 SMMC Prop 4 grants (AB 100: $31.349M appropriated; examples $2.2M LA County Fire, $400k MRCA, $1.315M MRCA visitor-serving, all 2025).
- S13 WCB for habitat/corridor/stream work where the site is genuinely riparian, wetland, or wildlife-corridor.
- S09 CAL FIRE UCF for urban-forest work at the wildland-urban interface edge.
- ILLUSTRATIVE split: SMMC 50% / WCB 30% / CAL FIRE UCF 20%. ILLUSTRATIVE. Do not use outside the SMMC Zone / Rim of the Valley corridor.

### 6D. Sound wall / freeway-edge barrier + vegetation
- S05 LPP — sound walls for pre-1987 freeways listed as eligible in the 2017 SB 1 summary; current eligibility NR — verify in guidelines. Only for jurisdictions with a voter-approved transportation tax/fee.
- L05 Measure R expenditure categories include soundwalls (transportation-only).
- F03 BUILD/RAISE only if the barrier is part of a larger regional-impact surface-transportation project — a standalone wall is a weak fit.
- ILLUSTRATIVE split: LPP 50% / Measure R 40% / local 10%. ILLUSTRATIVE; verify LPP sound-wall eligibility before scoping.

## 7. EV charging, energy, undergrounding, and smart streets

### 7A. Community EV charging hub (curbside / lot / library / park edge)
- F07 CFI Community Charging — no future NOFO date; last round announced Jan 2025; do not present as open. F06 NEVI is corridor-constrained and does not fit neighborhood streets before corridor-buildout certification.
- U03/U04 SCE Charge Ready (Transport / Light Duty) make-ready — 2020–2021 guides; current status/budget NR; re-check before budgeting. U06 LADWP Charge Up LA! amounts are SECONDARY ONLY — verify on the LADWP page.
- U13 LCFS credits — ongoing operating revenue only (1 credit = 1 MT CO2e; price NR from a primary source; vendor ranges flagged, do not use as current price). Assign credits in the operator contract.
- ILLUSTRATIVE split: CFI or state charging funds 50% / utility make-ready value 30% / site host + LCFS-backed operator contribution 20%. ILLUSTRATIVE; LCFS is revenue over time, not upfront capital.

### 7B. Solar canopies + storage on a public building / parking lot
- F01 IRA elective pay — secondary-only rates (30% base for Sec. 48E where wage/apprenticeship or <1 MW conditions met, 6% otherwise, plus possible adders). NOT primary-verified; post-2025 law changes UNVERIFIED. Verify with tax counsel and IRS guidance. Do not rely on any percentage from this file.
- S12 EPIC (CEC) only if the project is a genuine energy demonstration (community solar + storage + electrification in one neighborhood), not a grant for shade/paving alone.
- U07 LADWP Feed-in Tariff — SECONDARY ONLY (up to 14.5¢/kWh, 20-year PPA, 30 kW–10 MW, carport incentive up to $1.70/W). Verify on the LADWP FiT page; do not assume a city street project qualifies.
- ILLUSTRATIVE split: elective-pay credit value 30% / EPIC or other energy grant 40% / FiT/PPA-backed financing 30%. ILLUSTRATIVE and the highest-verification-risk stack in this file.

### 7C. Undergrounding overhead lines on a civic / scenic corridor
- U08 Rule 20A — ONLY banked credits; no new allocations after Dec 31, 2022; all credits must be used before Dec 31, 2033; program ends 2033. Do not budget Rule 20A as new money unless the city holds banked credits (e.g. Long Beach Cherry Avenue, ~$21M credits, 1.5 miles).
- U08 Rule 20B/20C — applicant-funded (20B with a ratepayer contribution whose split is NR from primary sources; the 20–40% vendor claim must not be used).
- L17 Development Agreement or L04/L05 Local Return only where the undergrounding is part of an eligible transportation/negotiated-benefit scope — verify; undergrounding alone is NR as Local Return-eligible.
- No ILLUSTRATIVE split is offered: if there are no banked 20A credits, the project is applicant-funded (20B/20C) and the stack is a local capital decision, not a grant stack.

### 7D. Smart streetlights / sensors / bus shelters with shade + Wi-Fi
- U14 STAP (City of LA only) — operator-funded shelters/shade under a 10-year contract to Dec 31, 2032; request a STAP site rather than proposing a parallel advertising deal. City revenue share and deployment count NR.
- U15 5G small-cell pole leases — HISTORIC 2018 figures only ($175/device/year Verizon deal; $270 FCC cap as reported); current fee schedule NR. Do not budget per-pole revenue.
- U10 CPA programs (CPA territory only, not LADWP) for battery-backed power at community sites — $2,000 Sun Storage rebate verified on the CPA homepage; Innovation Fund amounts/cycles NR.
- No percentage split: STAP is in-kind infrastructure delivery, not a cash grant; pole-lease revenue is unverified for 2026.

## 8. Cleanup, stewardship, and maintenance

### 8A. Neighborhood clean team + planting + upkeep (with paid local hiring)
- S10 Clean California CCEP — $25M to 90 projects announced Feb 2026; Compton $200,000 (FY2025-26) verified; grants must not displace people experiencing homelessness. Next cycle NR.
- L02 Measure W Municipal (only the stormwater-eligible upkeep elements, and only within the Municipal restriction — verify; Cerritos restriction cited in L02 is Cerritos-specific).
- U17 Philanthropy / U16 RAP sponsorship for stewardship, programming, and maintenance endowment via a nonprofit fiscal sponsor — no open program verified.
- ILLUSTRATIVE split: CCEP 55% / Measure W Municipal (eligible elements only) 25% / philanthropy/sponsorship 20%. ILLUSTRATIVE.

### 8B. Turf-to-native conversion on medians, parkways, and public land
- U01 LADWP Turf Replacement ($5/sq ft residential to $25,000 max; commercial/public $6–$7/sq ft tiers as published Nov 2, 2026 — re-check; conflict with $9–$10 limited-time news item flagged) + U02 MWD base $2/sq ft (stacks as LADWP $3 + MWD $2 = $5 residential).
- L01/L02 Measure W where the conversion is a stormwater-capture design (rain capture feature, permeable surfaces), not decoration alone.
- S08 Urban Greening where the conversion is part of a heat-refuge green street/alley with public access.
- ILLUSTRATIVE split: turf rebates 30% / Measure W 40% / Urban Greening 30%. ILLUSTRATIVE; rebate caps (sq ft / per-meter limits) bind first — a large median may exceed the rebate caps.

---

## Stacks NOT offered (and why)

- **Any stack using Neighborly (U18):** defunct 2019. Not a source.
- **Any stack using biodiversity credits (U19):** no urban-applicable market verified. Do not budget credit revenue.
- **Any stack using RECs (U20), Metro joint development (U21), solar-PPA parking lots (U22), or Waymo/telecom ROW leases (U23):** not verified / none found. They appear in the CSV as NR rows so the gap is visible; they must not be presented as funding.
- **Any stack using NMTC (F16), Opportunity Zones (F17), or LIHTC (F18):** not retrieved (rate-limited). Re-verify from CDFI Fund / IRS / California Tax Credit Allocation Committee primary sources before use.
- **Any stack using Coastal Conservancy (S18), Prop 2 schools (S19), IIG (S20), or REAP 2.0 (S21):** not retrieved (rate-limited). In particular, do not state REAP 2.0 was cut or remains funded.
- **Any stack using a City of LA Mobility Plan / transportation impact fee (L18):** name and status not verified. Do not cite such a fee as current.
