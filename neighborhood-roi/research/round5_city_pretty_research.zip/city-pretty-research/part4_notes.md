# City Pretty — Part 4: Notes on everything not verified

Date: 2026-11-02. Companion files: `part4_funding.csv` (81 data rows) and `part4_stacks.md`.
Rule used throughout: NR = not recovered from a source retrieved in this research. NR means "not found in this run" — it does NOT mean the program, amount, or example does not exist.

## 1. Method and limits — read before using any number

- Research was done by four parallel researchers using `browser.search` and `browser.open` on 2026-11-02. Much of the evidence is search-result snippets, not opened primary guideline/NOFA PDFs. Where a field was not in a retrieved snippet it is NR, even if the program plainly has such a field in its real guidelines.
- URLs in the CSV were copied verbatim from search/open results. A URL being present does not mean the page was fully read; several rows rely on snippets plus a cited page. Re-check every amount, match, deadline, and eligibility rule in the current primary guideline/NOFA before budgeting or applying.
- Dollar year is given only where a retrieved source stated one. Otherwise it is NR. Amounts are nominal as stated; no inflation adjustment was made.
- Stacking rules, typical award sizes, and match percentages are NR for most rows. Do not assume federal/state/local funds stack freely, or that one fund can be match for another, without the current guidelines.
- LA example awards are NR for most rows. A missing LA example means none was retrieved in this run, not that no LA project was ever funded.
- Status "as of late 2026" is stated only where a retrieved source supports it. Where the CSV says "status not recovered" or "NR", no late-2026 status conclusion should be drawn.

## 2. Searches blocked by rate limiting (HTTP 429) — gaps, not findings

A batch of searches in each research strand returned HTTP 429 (Too Many Requests) and, per the rate-limit instruction, was not retried in that run. The following were therefore NOT verified and must be re-run before any use:

- **Federal:** New Markets Tax Credit (F16), Opportunity Zones (F17), Low-Income Housing Tax Credit (F18) — no administrator, amount, eligibility, or LA example retrieved. IRS elective-pay primary pages and One Big Beautiful Bill Act text — not retrieved (F01/F19 rest on secondary summaries only). USDOT/HUD award lists filtered to Los Angeles — not retrieved, so every federal LA example is NR.
- **State:** California State Coastal Conservancy (S18), Prop 2 (2024) schools bond (S19), HCD Infill Infrastructure Grant (S20), HCD REAP 2.0 (S21) — all fields NR. In particular, whether REAP 2.0 was cut, frozen, changed, or remains active is NOT established by any source in this research. Do not state either outcome.
- **Local:** City of LA Mobility Plan / transportation impact fee (L18) — name, rate, administrator, and status NOT VERIFIED. Do not cite a citywide transportation impact fee, Westside fee, or Mobility Plan fee as current/active on the basis of this research.
- **Utilities/creative:** Renewable Energy Certificates (U20), Metro joint development / land value capture (U21), solar on public parking lots with PPA revenue — LA/CA example (U22), Waymo/telecom right-of-way lease revenue — LA example (U23), City Forest Credits LA/CA projects and prices (see U11). SCE business energy-efficiency rebates, LADWP standalone solar rebate / net-metering terms / SGIP, and any operating successor to Neighborly — no primary page verified; none is rowed as a source.

## 3. Companies, programs, and markets: verified, defunct, or none found

### Verified real (with limits stated in the CSV)
- **City Forest Credits / Urban Forest Carbon Registry (U11):** REAL. A 501(c)(3) nonprofit registry in Seattle with published Afforestation/Reforestation Protocol v11 and Preservation Protocol v14 (2026-08-10). NO LA/CA project, credit volume, or credit price was verified. Do not quote a price. A 26-year (planting) or 40/100-year (preservation) commitment applies.
- **Sidewalk and Transit Amenities Program — STAP (U14):** REAL and operating in the City of Los Angeles. Contract C141478 with Tranzito-Vector, LLC, executed 2022-09-29, 10-year term to 2032-12-31; scope 3,000 shelters and 450 shade structures. Current deployment count and City revenue share NOT recovered. STAP is the only permitted outdoor-advertising structure program in LA public right-of-way per a 2026 city report — do not propose a parallel shelter-advertising deal.
- **Safe, Clean Water Program Credit Trading / TCTUs (U12):** REAL program described on a live LA County page. No completed trades or volumes verified.
- **California Low Carbon Fuel Standard credits for EV charging (U13):** REAL CARB program, verified via secondary/aggregator sources only; primary CARB page and current price NOT recovered. Vendor price ranges ($50–$65/MT in 2026; $200 cap in 2016 dollars) must NOT be used as a current price.
- **RAP sponsorship/naming policies (U16):** REAL policies verified. No open catalogue or rate card recovered; the $40,000 Lotus Festival sponsorship is a verified example value, the $20,000/year PepsiCo proposal is a DRAFT, not a confirmed award.
- **Philanthropic funders named in U17** (California Community Foundation, Los Angeles Parks Foundation, Annenberg, Taper, Gilbert): verified as LA givers/donors in LANLT history. NO specific open grant program, amount, or deadline was verified. U17 is a category row, not a fundable program.
- **Measure J (L12):** VERIFIED as the 2020 LA County Care First Community Investment charter amendment (not a transit or parks measure). Measure A (2024) homelessness (L09) is verified as distinct from Measure A (2016) parks (L03) — same letter, different measures, years, and purposes. Do not conflate them.

### Defunct — plainly not a source
- **Neighborly (U18):** DEFUNCT. Civic microbond / municipal-bond crowdfunding startup; defunct 2019, bankrupted, defaulted October 2019 after failing to secure funding. Do NOT list as an operating funding source in 2026. No operating successor was verified.

### None found — do not budget
- **Biodiversity credits for urban projects (U19):** NONE FOUND. No voluntary biodiversity-credit market applicable to LA urban neighborhood projects was verified. Distinct from species/wetland mitigation and conservation banking (e.g. Buck Ridge Conservation Bank, Madera County, approved 2026-09-29), which offsets permitted impacts and is not revenue for voluntary beautification. Vendor commentary citing $30–$35/unit and an $8M nascent market is flagged as vendor/advocacy and must not be used.
- **Stormwater credit trading beyond the Measure W TCTU program:** no other trading program in LA County/CA was verified. U12 is the only stormwater-credit row.
- **Waymo/telecom ROW lease revenue (U23), 5G small-cell current fee schedule (U15), STAP City revenue (U14), TCTU transaction volumes (U12), LCFS current price (U13):** none found / not recovered. Historic 2018 5G figures ($175/device/year; $270 FCC cap as reported) must NOT be used as 2026 revenue.
- **Solar on public parking lots with PPA revenue, LA/CA example (U22) and Metro joint development (U21):** none verified (rate-limited). The only solar-revenue item retrieved is U07 (LADWP FiT, secondary-only).
- **Renewable Energy Certificates (U20):** not verified at all in this run. No price, registry, or LA example should be cited from this research.

### Not researched under Part 4 — no conclusion offered
- **"Treety"** (tree-planting / Measure W technology named in the original global-rules example): Treety was NOT in the Part 4 source list and was not researched in this Part 4 work. No conclusion is offered here about whether Treety exists or what it does. That verification belongs to Part 1 (improvement library / Measure W scoring), and the Measure W Regional vs Municipal structure, scoring, and quantification questions must be answered there from Safe, Clean Water Program guidelines — not inferred from U12 (credit trading) or L01/L02 (revenue splits) alone.
- **Other CEC programs beyond EPIC (S12), other SGC programs beyond TCC/AHSC/CRC, other SB 1 formula programs beyond ATP/LPP/TCEP/STPG:** no additional program names were verified in the searches run. The SB 1 summary also mentions bridge/culvert maintenance and Freeway Service Patrol funding and a Local Streets and Roads formula share, but those were not verified as standalone rows. Do not invent program names from this note — check CTC/Caltrans and CEC/SGC primary pages.

## 4. Secondary-only / vendor-flagged figures — re-check before use

These rows or fields rest on secondary, vendor, advocacy, or Wikipedia sources, not on an opened primary page. They are flagged in the CSV `sources` column; treat them as leads, not as established facts:

- F01 IRA elective pay: 30%/6% Sec. 48E rates, adders, applicable-entity list, filing mechanics — secondary summaries only (Illinois Power Agency presentation, blogs). No IRS/Treasury primary page retrieved.
- F19 Sec. 30C EV-charger credit: existence/scope secondary-only; the claim it "ended June 30, 2026" comes from ONE secondary source and is UNVERIFIED. Do not rely on it without IRS guidance / OBBBA text.
- F03 BUILD/RAISE match (80/20), F02 SS4A match and award ranges, F05 CRP match, F11 Section 108 typical range: secondary summaries/aggregators, not primary NOFOs.
- U06 LADWP Charge Up LA! amounts and U07 LADWP FiT rate/terms: secondary sources only; primary LADWP pages not opened.
- U13 LCFS prices, U15 5G figures, U08 Rule 20B 20–40% utility-share claim: vendor/press claims, flagged; the 20–40% claim must not be used.
- L10 Measure ULA unit-cost figure ($780,000/unit) and L12 Measure J categories via Reimagine LA, L14 tree-fee via an advocacy site, S02 Prop 68 allocations via Wikipedia/consultant summaries, S06 TCC administration via secondary summary: flagged secondary in the CSV.
- S09 CAL FIRE award range ($150k–$1.5M / up to $3M regional), S11 STPG min/max figures: secondary summaries; verify in current solicitation/guide.
- L09 $11.4M LACAHSA deployment, L11 $16M HHH loans, S10 Lancaster $172,000 CCEP: secondary news/blog summaries; primary award lists not retrieved.

## 5. Federal late-2026 status — what is and is not established

Do NOT present any federal program as cut, frozen, terminated, or fully funded on the basis of this research alone, except where the CSV gives a sourced, dated fact:

- **BRIC (F13):** Sourced history only — FY2024 NOFO retracted Feb 2025, termination announced Apr 4, 2025, Dec 11, 2025 court ruling held termination unlawful, Mar 6, 2026 order required restoration, restart announced Mar 2026, combined FY2024–FY2025 round closed July 2026. Post-July-2026 open-round status NR.
- **NEVI (F06) / CFI (F07):** Only primary documents are FHWA's Aug 11, 2025 NEVI guidance and FHWA's CFI page (no future NOFO date). Suspension/injunction/restart/cancellation-proposal claims are secondary press/CRS reporting only.
- **RCP/NAE (F04):** No current USDOT NOFO/status retrieved. Caltrans "likely not to return" and a reported 2025 $3.1B rescission proposal are not proof of enactment or termination.
- **USDA U&CF IRA funds (F15):** IRA Tracker (citing P.L. 119-21 Sec. 10201, One Big Beautiful Bill Act of 2025) reports unobligated funds rescinded. Amount rescinded vs. already obligated, and whether any CA/LA funds remain, NR. Do not present the program as entirely ended or as currently open.
- **IRA elective pay / Sec. 48E / Sec. 30C post-2025 changes (F01/F19):** UNVERIFIED. Secondary claims that elective pay was kept, and that 30C ended June 30, 2026, must not be presented as established law.
- **CDBG (F10), CIG (F09), CRP (F05), SS4A/BUILD (F02/F03):** IIJA authorization through FY2026 is sourced; post-FY2026 authorization/funding is NR. CIG's Oct 1, 2026 revised methodology (40% starting share) is PROPOSED only (Federal Register 91 FR 62586), not final policy.
- **EPA Brownfields (F12):** FY2027 grants to be funded solely by annual appropriations per EPA page; BIL/IRA supplemental funding is not described as continuing in that FY2027 note. That is the only funding-continuation statement sourced.

## 6. Discrepancies and conflicts found in retrieved sources — do not reconcile without the primary document

1. **Measure W total:** $280M vs $285M per year (both in the FY25-26 City WISP) vs $300M in an older Torrance audit note. CSV uses the $280–285M WISP range.
2. **Measure A (2016) parks parcel rate:** ballot text 1.5¢/sq ft vs one secondary source stating 1.6¢. Verify in the RPOSD levy resolution.
3. **Measure H → Measure A (2024) effective dates:** County page says Measure A effective April 1, 2025; Burbank report says Measure H concluded June 30, 2025 and Measure A effective July 1, 2025. Unresolved.
4. **Measure H annual revenue:** $355M/yr (2017 estimate) vs "over $500M/yr" (Glendora FAQ, no year) vs "over $600M/yr" (Move LA 2023). Year/source must accompany any figure.
5. **TCC Round 6 total:** $98.4M (SGC NOFA) vs $98.8M (secondary summary). CSV uses the SGC NOFA figure.
6. **NAE total (F04):** $3.2B (Caltrans) vs $3B (secondary history). Unresolved.
7. **BUILD FY2026 total (F03):** $1.5B made available (NOFO summaries) vs ~$1.73–$1.74B reported awarded for 127 projects. Award list not retrieved.
8. **CFI awarded total (F07):** $1.779B (NASEO) vs $1.8B / $1.7B in other summaries. Reported as a range.
9. **Prop 4 tranches (S01):** ~$3.3B authorized in 2024-25 + 2025-26 Budget Acts (LCI) vs $2.1B proposed additional in 2026-27 (Governor budget via LCI) vs $2.7B for a further year (LAO). Different budget-action framings — do not add together.
10. **RMC Prop 4 allocations (S15):** listed program allocations ($40M + $33.5M + $48M) sum to more than the stated ~$112M life-of-program total. Reconciliation NR — do not sum them.
11. **LPP split (S05):** 60% Formulaic $108M + 40% Competitive $72M + a $20M incentive set-aside within the $200M total. Reconciliation NR.
12. **LADWP turf rebate (U01):** current page tiers ($6/$7 commercial/public) conflict with LADWP news 2025-10-16 reporting limited-time $9–$10/sq ft. Use the current page and re-check before budgeting.
13. **Urban Greening disadvantaged share (S08):** 40% intent (2026 cycle) vs 75% in an earlier cycle. Cycle-specific — verify in the current guideline.
14. **AHLF collections (L15):** FY2023-24 figure $34,896,521 appears in garbled source text — verify in the primary LAHD memo/Council file before citing.
15. **Measure J Nov 2026 ballot outcome, Measure HHH remaining balance, ULA/AHLF litigation and expenditure-plan status, TCC/CRC Round 6 award outcomes, Urban Greening Round 1 award outcomes:** all NR as of Nov 2, 2026 (the research date; the Measure J fix was proposed for the Nov 2026 ballot). Do not assume any outcome.

## 7. Rows that are placeholders, not programs

- **F16 NMTC, F17 Opportunity Zones, F18 LIHTC, S18 Coastal Conservancy, S19 Prop 2, S20 IIG, S21 REAP 2.0, L18 Mobility Plan fee, U20 RECs, U21 joint development, U22 solar PPA, U23 Waymo/telecom ROW:** included in the CSV as all-NR / not-retrieved rows so the gap is visible in the data. They are NOT verified funding sources and must not be cited as such, quoted for amounts, or used in a stack until re-verified from primary sources.
- **U18 Neighborly** is included as a DEFUNCT row for the same reason: so no future reader mistakes a historical name for a live source.
- **S01 Prop 4 and S02 Prop 68** are umbrella bonds, not single grant programs. Their totals must not be added to sub-program rows (S07–S09, S14, S15) — that would double-count.

## 8. Recommended re-verification before any application or publication

1. Re-run the 429-blocked searches (Section 2) and open the primary guideline/NOFA PDFs for: ATP (S04), LPP (S05), TCC/CRC (S06/S16), Urban Greening (S08), RMC (S15), SS4A/BUILD/CFI NOFOs and USDOT award lists (F02/F03/F07), HUD FY2026 CPD allocations for City/County of LA (F10), IRS elective-pay pages and OBBBA Sec. 48E/30C text (F01/F19), CDFI Fund NMTC + IRS OZ + CTCAC LIHTC (F16–F18), HCD IIG/REAP 2.0 (S20/S21), Coastal Conservancy (S18).
2. Re-check on live primary pages before budgeting: LADWP turf and Charge Up LA! rates (U01/U06), LADWP FiT tariff/capacity (U07), SCE Charge Ready current guides (U03/U04), CPA terms including the Reliability+ adder (U10), LAMC tree in-lieu current fee schedule (L14), Quimby current fee schedule (L13), Measure W Municipal agreement restrictions for the City of LA (L02).
3. Settle the discrepancies in Section 6 from the primary document (ordinance, levy resolution, NOFA, award list) — not from a secondary summary — before citing any disputed figure in a filing or in the City Pretty map UI.
4. For any stack in `part4_stacks.md`, confirm in each source's current guideline: (a) the project is eligible, (b) the funds can stack, (c) one fund can serve as match/leverage for another, and (d) the round is open. The stacks file labels ILLUSTRATIVE splits explicitly; no ILLUSTRATIVE split should ever be shown to a user as a program rule.
