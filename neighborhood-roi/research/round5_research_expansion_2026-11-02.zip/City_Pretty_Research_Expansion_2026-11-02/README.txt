CITY PRETTY — RESEARCH EXPANSION
As of 2026-11-02

Open City_Pretty_Research_Expansion.html for the searchable table viewer and
historical EIFD allocation illustration. It is self-contained and requires no
account or network to view the records. External source links require network.

The original V2.1 map and its recommendations were not changed by this package.
This is a research catalog and implementation package, not a claim that every
new intervention has a validated positive return or three funded grant plans.

CONTENTS
tables/ — 17 CSV tables; Part1, Part2, EIFD cases and Part4 retain the requested
column order. The viewer can export the full table or search matches as CSV.
data/ — consolidated JSON, historical example input and link-retrieval ledger.
code/ — source assembly, HTML/CSV generation, validation, standalone EIFD
arithmetic/funding-rule module and its tests; reference snapshot included.
qa/ — table roundtrip/identifier checks, module checks and file hashes.

READ THESE LIMITS
NR means not recovered, not zero. Cost comparators may exclude land, design,
utilities, contingency, operations or replacement; missing full costs are not
filled with guesses. Original dollar vintages remain unchanged.

A/B/C/D grades are outcome-specific. LA classroom test-score evidence does not
establish a home-price coefficient. ADU host-parcel evidence is not a neighbor
spillover. Calculated Wald intervals are explicitly distinguished from the
published authors' preferred inference and from ranges across models.

Funding rows distinguish authority from cash still available to a new project.
Expired, reserved, paused or closed programs remain so marked. Conditional
routes must pass actual applicant, geography, current-budget and agreement
checks. An NR route slot is not a financing proposal. Unverified component
leads are excluded from funding_ids. Do not combine SCWP money with tradable
SCWP credits for the same improvement. Review the exact current guidelines.

Official endpoints may be metadata-only in this research. Parent-listed GIS
layers are not asserted to have been successfully downloaded or coverage-
validated. Some published ZIP/CSV links redirected to bodies the research
tools could not parse; these failures are explicit. Paid/licensed data routes
are noted. No new raw-sale regression or independent local DiD is claimed.

EIFD EXAMPLE
The La Verne 2018 source's potential new-development AV and participant shares
produce a static annual allocation of USD1,577,587.50. This is not its phased
growth forecast, current assessed value, or spendable bond capacity. Borrowing
yield, DSCR, term, net revenues and closing deductions remain NR. School/ERAF
shares are excluded; agency-specific legal base years and actual allocation
factors are required for a real TRA model. See part3_worked_example.csv.

CODE
With Node installed: node code/test_eifd.mjs
Import the dependency-free code/eifd_calculator.mjs into the map to use
assessedIncrement, annualAllocation, annualTRAAllocation, screenLevelDebt and
reviewFundingStack. No growth, yield, DSCR or statutory sunset is guessed.
Synthetic numbers inside the tests are fixtures, not research estimates.

Python standard-library scripts can rebuild the consolidated data and HTML.
The CSV authoring script uses @oai/artifact-tool from the authoring runtime;
that dependency is not bundled. Existing CSVs require no authoring dependency.
When rebuilding, CITY_PRETTY_RESEARCH_OUT can select an absolute output folder.

PRIORITIES AND OPEN QUESTIONS
ranked_25_additions.csv contains the requested ranked implementation list.
creative_15_stacks.csv contains fifteen one-sentence routes, with percentages
NR unless tied to the expressly dated staff-report example.
unverified_and_NR.csv enumerates broad and item-specific gaps.
notes.csv records schema decisions and limitations.

Verification covers CSV schemas/roundtrips, references, calculator tests and
JavaScript syntax. Browser visual verification was unavailable under an
earlier local-file access restriction; no alternate browser workaround used.
