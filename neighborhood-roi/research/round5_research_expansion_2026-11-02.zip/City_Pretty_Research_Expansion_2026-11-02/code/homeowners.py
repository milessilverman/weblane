from data import S,SOURCES,cite,P2,prior_source
HOME=[]
def H(id,name,category,rebates='NR',tax='NR parcel-specific assessment treatment; distinguish repair from assessable new construction',permit='NR exact city requirements; verify scope with local building authority',src=(),cost='NR',year='NR',value='NR',grade='NR',savings='NR; requires actual usage, tariff, equipment and operating baseline'):
 row=dict(zip(P2,[id,name,category,cost,year,value,'NR intervention-specific resale coefficient; CI/N NR',savings,rebates,tax,permit,'NR',grade,cite(*src) if src else 'NR recovered primary cost/value record']))
 HOME.append(row);return row
def populate():
 S('adu_tax','LA Assessor ADU guidance','https://assessor.lacounty.gov/homeowners/adu/1000','ADU valuation and SB9 updates; local entitlement rules may be newer')
 S('sb9_county','LA County SB9 guidance','https://planning.lacounty.gov/planning-permits/sb-9/','Restrictions; urban lot split; final map before development')
 S('mills_pause','CityLA Mills Act intake','https://planning.lacity.gov/node/133403','New applications temporarily on hold')
 S('solar_lta26','BOE2026/013 property tax legislation','https://boe.ca.gov/proptaxes/pdf/lta26013.pdf','SB710 summary; section73 inoperativeJan1 2027')
 for id,name in [('home_adu','Detached ADU'),('home_jadu','JADU'),('home_garage_adu','Garage conversion to an ADU'),('home_prefab_adu','Prefab/modular ADU')]:
  r=H(id,name,'Housing',rebates='private_capital; local ADU financing program NR',tax='New-construction portion may be assessed; do not reset unchanged original home/land assessment or assume a new ADU is tax-free.',permit='Yes: zoning/building and utility/site approvals; JADU/conversion scope differs.',src=('adu_tax',prior_source(100),prior_source(101)))
  r['value_source']='Published LA host-parcel ADU study and separate neighbor-density study are cited; exact scope-matched coefficient/CI/N not independently re-recovered here. Do not assign a host-parcel premium to neighbors.'
 H('home_sb9','SB9 lot split / duplex','Housing',rebates='private_capital; new construction financing terms NR',tax='Lot division alone is not automatically a market-wide reassessment; new construction, ownership transfers and resulting parcels require assessor review.',permit='Yes: urban lot split/final map and separate development approval. Site/hazard/tenancy restrictions apply.',src=('sb9_county','adu_tax'))
 for id,name,rebates,tax,permit,src in [
 ('home_solar','Owned rooftop solar','sgip (income/project-qualified; remaining reservations NR); fed25d EXPIRED for new late2026 installations','R&T73 qualifying active-solar new-construction exclusion beforeJan1 2027; qualifying pre-deadline systems can retain exclusion until ownership change; not a blanket property-tax exemption.','Yes: electrical/building and utility interconnection; roof/structural scope varies.',('solar_tax','solar_lta26','solar_value','sgip','irs_end')),
 ('home_battery','Home battery storage','sgip; cpa if eligible; fed25d EXPIRED','Standalone battery exclusion NR; do not assume active-solar treatment for every battery.','Yes: electrical/fire/structural requirements and utility approval as applicable.',('sgip','irs_end')),
 ('home_heatpump','Heat-pump HVAC','dwp_consumer: up to$2,500/ton, rating-dependent; heehra fully reserved; fed25c EXPIRED','NR new-construction versus replacement treatment for exact scope.','Yes for LA rebate scope: final approved building/safety permit required.',('dwp_hp','heehra','tech','irs_end')),
 ('home_hpwh','Heat-pump water heater','dwp_consumer: up to$2,500/unit, eligibility-dependent; heehra fully reserved; fed25c EXPIRED','NR exact installation assessment.','Plumbing/electrical/mechanical approval as required; final permit required by LADWP rebate.',('dwp_hp','heehra','irs_end')),
 ('home_induction','Induction cooktop/range','heehra fully reserved; other local incentive NR; fed25c is not a generic cooktop credit','NR exact project.','Electrical permit if adding/changing circuit; gas decommissioning/local rule NR.',('heehra','irs_end')),
 ('home_panel','Electrical service/panel upgrade','sce_home: up to$4,200 panel+EV-outlet if eligible; dwp_ev eligible installation costs; fed25c EXPIRED','NR; panel upgrade alone is not proven tax-free.','Yes: electrical permit and utility service coordination.',('sce_home','dwp_ev','irs_end')),
 ('home_ev','Home EV charger / dedicated outlet','dwp_ev: up to$1,000 charger +$250 meter, eligible low-income additional$500; sce_home up to$1,000 outlet-only or distinct panel package; fed30c EXPIRED','NR exact installation assessment.','Electrical approval/licensed installer as required; permit fees can be eligible LADWP costs.',('dwp_ev','sce_home','irs_end')),
 ('home_insulation','Attic/wall insulation and air sealing','dwp_consumer current item-specific rebate NR; fed25c EXPIRED','NR exact repair/new-construction treatment.','NR by scope; do not assume permit exemption for structural/ventilation work.',('dwp_hp','irs_end')),
 ('home_windows','Window replacement','dwp_consumer item-specific rebate NR; fed25c EXPIRED','Routine replacement versus new opening/reconstruction must be assessed separately.','NR local like-for-like exemption; new openings/structural work require review.',('newconstruction_tax','irs_end')),
 ('home_coolroof','Cool-roof replacement','dwp_consumer product-specific rebate NR; fed25c EXPIRED','NR; replacement and structural reconstruction differ.','Re-roof permit and applicable cool-roof/fire code requirements.',('newconstruction_tax','irs_end')),
 ('home_turf','Turf replacement / climate-appropriate garden','mwd: base$2/sqft up to5,000sqft/year; retail agency additions NR','NR exact assessment; water rebate is not a property-tax exclusion.','Reserve rebate before work; drainage/grading/ROW permits as applicable.',('mwd',)),
 ('home_greywater','Greywater reuse','Local utility rebate NR; private_capital','NR exact plumbing/site scope.','NR local exemption for qualifying laundry systems; building/plumbing approval for broader systems must be verified.',()),
 ('home_rainbarrel','Rain barrels / cisterns','mwd device-specific rebate NR; scw_credit only if approved project criteria met','NR exact structure/plumbing assessment.','NR by volume, plumbing and structural scope; mosquito/overflow controls required.',('mwd','scw_credit')),
 ('home_irrigation','Smart irrigation / soil-moisture controls','mwd device-specific rebate NR','NR exact installation.','NR local plumbing/backflow/irrigation requirements.',('mwd',)),
 ('home_tree','Front-/back-yard shade trees','cityplants: up to7 free supplied yard trees in CityLA; owner planting/watering costs remain','NR; no measured tax reassessment rule assigned to planting.','Private-yard planting rule NR; parkway planting needs city permit; do not plant a yard-program tree in ROW.',('cityplants','cityplants_faq')),
 ('home_seismic','Raised-foundation brace-and-bolt retrofit','ebb: up to$3,000 and qualifying income supplemental up to$7,000; current registration NR','R&T74.5 seismic-safety new-construction exclusion; notify assessor within30days and documents within6months per BOE table.','Yes: code-compliant building permit and final inspection.',('ebb','crmp','newconstruction_tax')),
 ('home_softstory','Small-home soft-story retrofit','ebb/ESS availability and specific award NR','R&T74.5 may apply to qualifying seismic work; additional construction is separate.','Yes: engineered retrofit/building review.',('crmp','newconstruction_tax')),
 ('home_hardening','Wildfire home hardening','wildfire_discount: insurer-specific quote, universal$/%NR; state grant program reservation NR','NR; fire-system/new-construction exclusions depend on exact scope.','NR by vent/roof/window/deck scope and local fire/building rule.',('wildfire_discount','wildfire_discount_faq')),
 ('home_zone0','Ember-resistant Zone0 / defensible space','wildfire_discount: exact annual premium change NR','NR; landscaping alteration is not assigned a universal reassessment effect.','Verify current state/local requirements and protected-tree rules; no blanket claim that all planting within a distance is illegal.',('wildfire_discount','wildfire_discount_faq')),
 ('home_vents','Ember-resistant vents / enclosed eaves','wildfire_discount: exact annual saving NR','NR exact project.','NR local building/fire product and permit requirements.',('wildfire_discount',)),
 ('home_mills','Mills Act historic-property contract','mills_act: CityLA new applications paused; existing contracts and othercities separate','Contract-specific restricted-property valuation with preservation duties; savingsNR; HPOZ designation alone does not create a contract.','Contract/application and preservation work approvals; current CityLA new intake paused.',('mills_pause','newconstruction_tax')),
 ('home_pace','PACE financing of eligible upgrades','pace: loan/assessment financing, not a rebate','Assessment payment is financing debt, not a Proposition13 base-value exclusion.','Underlying improvement permits; program/provider disclosures and mortgage/lien rules.',()),
 ('home_v2h','Bidirectional vehicle-to-home charging','Current vehicle/charger/utility-specific incentive NR; fed30c EXPIRED for newlate2026 service','NR exact equipment/integration assessment.','Yes as applicable: interconnection/transfer equipment/electrical permits; verify compatible vehicle and warranty.',('irs_end',)),
 ('home_microgrid','Islandable home solar+battery microgrid','sgip if eligible and reserved; cpa conditional; fed25d EXPIRED','Solar/battery components may receive different assessment treatment; do not blanket-exclude battery/new structures.','Electrical/fire/interconnection; certified transfer/islanding design.',('sgip','irs_end','solar_tax')),
 ('home_smart','Smart-home controls / leak alarms / safety sensors','Device/utility incentive NR','NR exact permanently installed versus personal-property treatment.','NR by device; new wiring/plumbing/locks or life-safety systems require applicable review.',()),
 ('home_fiber','Fiber hookup / in-home network','Current service-provider construction/promotion subsidy NR','NR exact physical installation.','Provider ROW permit is different from owner in-home work; local permit scope NR.',('fiber_effect','fcc')),
 ('home_office','Home office conversion','NR; private_capital','Routine room use, structural conversion and additions differ; no universal exclusion.','NR; structural/addition/electrical changes require relevant approval.',()),
 ('home_accessibility','Accessibility / universal-design retrofit','Local adaptation grant/loan NR; private_capital','R&T74.3 qualifying disabled-accessibility exclusion; documentation required; generic universal design may not qualify.','NR by ramp/bath/structural scope; accessible-building standards apply.',('newconstruction_tax',))]:
  H(id,name,'Owner upgrades',rebates,tax,permit,src)
 # National solar association is a measured USD/watt coefficient, not a percent
 # borrowed to new 2026 systems or a prediction of an individual house's sale.
 r=next(r for r in HOME if r['id']=='home_solar')
 r.update(resale_value_added='About$4/W ownedPV premium (2015 study; underlying sales2002–2013; not2026 dollars)',value_source='LBNL2015 abstract:22,822 sales,3,951PV homes,8states; CI NR; observational/hedonic, gradeC. NewLA premium NR.',grade='C')
 r=next(r for r in HOME if r['id']=='home_fiber');r.update(value_source='National2011–2013 study associates neighborhood gigabit/fiber availability with3.1% prices; not the causal effect of connecting one already-served house; CI/N NR.',grade='C')
 # Industry estimates: exact LA geography column, named-row locator. No claim
 # that a predicted resale contribution is an observed causal price increase.
 projects=[
 ('home_garagedoor','Garage-door replacement',4465,12124),
 ('home_entrydoor','Steel entry-door replacement',2540,5451),
 ('home_veneer','Manufactured stone veneer',13271,29216),
 ('home_kitchen_minor','Minor kitchen remodel, midrange',29765,37768),
 ('home_kitchen_major','Major kitchen remodel, midrange',86214,49079),
 ('home_bath','Bath remodel, midrange',27143,24312),
 ('home_access_bath','Bath remodel, universal design',44580,25480),
 ('home_window_cvv','Vinyl-window replacement project',23783,19799),
 ('home_roof_cvv','Asphalt-shingle roof replacement project',36417,26804),
 ('home_hvac_cvv','HVAC electrification, CVV specified project',19451,15039),
 ]
 for id,name,cost,value in projects:
  r=H(id,name,'Renovation',src=('cvv','newconstruction_tax'),cost=f'{cost}USD/project; industry scope-specific estimate, not an awarded bid',year=2025,value=f'{value}USD estimated resale contribution; not a measured sale-price effect',grade='D',permit='NR exact local scope; structural, electrical, plumbing and roofing permits as applicable.')
  r['value_source']='Zonda/JLC2025 LosAngeles column, named project row; industry estimate; CI/N NR; do not treat recoupment exceeding100% as guaranteed profit.'
 return HOME
