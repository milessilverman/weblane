"""Three prioritized CONDITIONAL routes per intervention; never fabricated shares."""
STACKS=[]

def build(improvements,funding):
    ids={f['id'] for f in funding}
    def add(id,rank,components,scope,notes=''):
        assert set(components.split(';'))<=ids,(id,components)
        STACKS.append(dict(improvement_id=id,rank=rank,funding_ids=components,shares_pct='NR',funded_scope=scope,status='candidate; not an award, executable financeplan or guarantee of open funds',notes=notes or 'Verify applicant, geography, currentavailability, match, grantagreement and separateinvoices. No inventedpercentageallocation.'))
    for x in improvements:
        id=x['id'];cat=x['category']
        if id=='treety':
            routes=[('private_capital;philanthropy','Prototype/research cost; verifiedcompanyfundingprogramNR'),('private_capital','Consentingfounder/investorfinance; actualcommitmentNR'),('general_fund','Onlya competitivelyapprovedeligibleprocurement/researchagreement; no verifiedagencyprogramorcontract')]
        elif id in ['green_street','bioswale','rain_garden','capture_park','permeable_pavement','creek_daylighting','green_alley']:
            routes=[('scw_regional;scw_municipal;general_fund','Approvedmodeledstormwatercapital/O&M; noSCWPcredittrading'),('urban_greening;development_agreement;general_fund','Eligiblegreening/design/site and separatelyfundeddrainage; grants/currentroundmayclosed'),('private_capital;philanthropy;scw_trade','Nonmunicipaltax-exemptsite only; noSCWPfunding at ANYstage; approvedfuturecreditsnotupfrontcapital')]
        elif id in ['street_trees','tiny_forest','urban_orchard','soil_cells','structural_soil','smart_irrigation','tree_inventory','urban_carbon']:
            routes=[('calfire_ucf;tree_fee;general_fund','Eligibleplanting/establishment/inventory withlocalfeeauthority; actualscopeprogram-dependent'),('urban_greening;scw_municipal;general_fund','Naturebasedstormwater/heatpackage; supportactualhydraulicbenefits'),('cfc;philanthropy;private_capital','Onlyprotocol-qualifiedtreecarbonproject; netproceeds/creditrights/permanence mustbeverified')]
        elif id=='schoolyard_green':
            routes=[('prop2_schools;urban_greening;general_fund','Eligiblecampuscapital andgreeningunderactualschool/grantapproval'),('scw_regional;scw_municipal;philanthropy','Qualifyingstormwatercampus; municipalpartner/O&Magreement; noTCTUs'),('philanthropy;private_capital;scw_trade','Qualifyingnonmunicipaltax-exemptschool; noSCWPfunding atplanning/build/O&M; engineer-approvedcredits')]
        elif id=='undergrounding':
            routes=[('rule20a;general_fund;private_capital','SCEqualifyingpublicbenefitconversion withactuallyavailablepriorworkcredits; LADWPseparate'),('rule20b;general_fund;private_capital','SCEapproved20Bscope; ratepayer20–40% referseligibleutilities, notfullproject'),('development_agreement;private_capital','Developer/ownerconversionincludingserviceconnections/telecom; actualROW/sitecontracts')]
        elif id in ['public_solar','neighborhood_battery','microgrid','resilience_hub']:
            routes=[('cec;fed48e;general_fund','Eligiblepubliclyownedgeneration/storagecapital; noordinaryoperationsinEIFD/bondbudget'),('solar_ppa;private_capital','PrivateownerPPA/lease; reconcilecredit/RECownership andfutureenergyobligations'),('tcc;sgip;general_fund','Onlyeligiblecommunity/utilitycomponents; programround,reservationsandper-itemeligibilitymayblock')]
        elif id in ['vpp','v2g','ev_hub','curb_ev']:
            routes=[('cec;private_capital;lcfs','Eligiblecharging/gridpilot withmetering,tariff/interconnection andcreditrights'),('cfi;private_capital;general_fund','Onlyeligiblepublicchargingcomponent; projectNOFO/currentavailabilityNR'),('private_capital;cpa;lcfs','Actualutility/aggregatoragreementandqualifiedchargeruse; 30Cexpired;VPP/V2GnotallCFIeligible')]
        elif id in ['adu','sb9','missing_middle','modular','printed_housing','homeownership']:
            routes=[('private_capital','Owner/developerequityandloan; directgrantNR forordinarymarketconstruction'),('private_capital;development_agreement','Lawfulnegotiatedpublicbenefit/land arrangement, notautomaticownergrant'),('private_capital;philanthropy','Onlyqualifiedshared-equity/affordablepilot; philanthropiccommitmentNR')]
        elif id in ['affordable_housing','clt','adaptive_reuse']:
            routes=[('lihtc;ahsc;ula','Eligibleaffordablerental/conversion package; allocationsandcurrentlyclosedroundmustbechecked'),('hcd_iig;linkage;private_capital','Eligiblehousing-relatedinfrastructure andadoptedcityfunding; scope-specific'),('cdbg;section108;private_capital','EligibleCDBGnationalobjective/publicbenefit; debtneedsrepayment; notallrentalnewconstructionqualifies')]
        elif id in ['sb79','hpoz','mills_act']:
            routes=[('general_fund','Planning/implementationadministration; no fullprivatedevelopmentcostomission'),('reap2;general_fund','Onlyeligiblehousingplanningactivities; HPOZ/MillsActworknotassumedREAPeligible'),('development_agreement;private_capital','Site-specificpreservation/affordabledevelopment obligations; newCityLAMillsActintakepaused')]
        elif id in ['noise_camera','speed_camera','alpr','drone_response','gunshot_detection','cameras','ai_traffic','adaptive_signals','smart_lighting','street_lighting','small_cell','fiber','public_wifi']:
            routes=[('general_fund;private_capital','Actualauthorizedpublictechnologyprocurement/service andbudget; noassumedcrimeorpricegain'),('development_agreement;private_capital','Onlylawfulscope/ROWattachmentobligations; privacy/maintenanceandprocurementreview'),('general_fund;pole_lease','Poleleaserevenueonlyiflawfullyavailableandactuallycontracted; notallcamerasqualifyforeveryutilitylease')]
        elif id in ['foot_patrol','violence_interruption','litter','graffiti','encampment','bid','code_enforcement']:
            if id=='encampment':routes=[('homeless_a2024;general_fund','Eligiblehousing/services underadoptedcontract'),('cfci;philanthropy;general_fund','Eligiblecommunity-ledhousing/services; notpoliceenforcement'),('private_capital;philanthropy','Committedhousing/servicepartner; clientrights andactualcostdenominator')]
            elif id=='violence_interruption':routes=[('general_fund;cfci','EligibleGRYD/communityviolenceprevention contract; exactCFCIscopeapprovalrequired'),('philanthropy;general_fund','Complementaryevaluation/outreach withcommittedpublicoperationfunds'),('bid_pb;general_fund','Onlylawfulspecial-benefitpreventiveservices; noassumedBIDwideviolencefunding')]
            else:routes=[('general_fund','Ongoingagencyservicesunderadoptedbudget; ordinaryEIFDoperationsnoteligible'),('bid_pb;general_fund','Onlylawfuldistrictspecial-benefitserviceswithinboundary'),('philanthropy;general_fund','Eligiblepilot/evaluationorcommunityservice; dependableannualfundingNR')]
        elif cat=='Transit & mobility' or id in ['sidewalks','traffic_calming','crosswalks']:
            if id in ['gondola','vertiport','av_service','av_shuttle','congestion_pricing','parking_cashout']:
                routes=[('private_capital;general_fund','Actualagency-authorizedpilot/concession/TDMimplementation; granteligibilitynotassumed'),('development_agreement;private_capital','Lawfulsite-specificaccess/curb/airspaceagreement'),('general_fund;philanthropy','Eligiblefeasibility/evaluation; capitalauthorizationandoperatingagreementstillNR')]
            elif id in ['rail_station','light_rail_line','brt','metrolink_upgrade','hsr_station']:
                routes=[('fta_cig;metro_m;metro_r','OnlyFTA/Metroeligibleprojectscope; CAHSRnotautomaticallyCIGeligible'),('metro_m;joint_development;general_fund','Dedicatedprojectallocationandcontractedpubliclandvaluecapture'),('eifd;metro_m;general_fund','Eligiblelong-livedcapitalwithlegallypledgedincrement; LA75yearTIFIAexceptiononlyifallconditionspass')]
            else:routes=[('atp;prop_c;general_fund','Onlyactive-transportationeligiblescope; busoperations/cashoutnotATPinferred'),('metro_m;prop_c;general_fund','Eligibletransportationcapital/localreturn, actualguidelinesgovern'),('development_agreement;general_fund','Lawfulsite-specificROW/accessimprovements withO&Mseparate')]
        elif id in ['oil_closure','brownfield','flood_retreat','hardening_zone','defensible_space','soft_story','lead_pipe']:
            routes=[('general_fund;private_capital','Responsibleagency/ownerorliableparty; exacthazardmitigationscope'),('hmgp;general_fund','Onlyeligibledeclared-disastermitigationscope; oilcleanup/leadworknotautomaticallyeligible'),('epa_brownfield;general_fund','Onlyqualifyingbrownfieldassessment/cleanup; ordinaryleadpipe/seismicworknoteligiblebyanalogy')]
        elif id in ['grocery','food_hall','night_market','main_street','outdoor_dining','farmers_market']:
            routes=[('private_capital;bid_pb','Ownercapital/operatingrevenue andlawfulBIDpublicrealmbenefit; noassumedstorepremium'),('nmtc;private_capital','Onlyqualifiedlow-incomebusiness/project throughallocatedCDE; notgenericretailgrant'),('cdbg;section108;private_capital','Eligibleeconomicdevelopmentwithnationalobjective/publicbenefit; actualrepaymentandprivatecosts')]
        elif id=='public_art':
            routes=[('percent_art;general_fund','Ordinance-eligiblecapitalartallocation andseparatemaintenancebudget'),('bid_pb;naming;private_capital','Lawfuldistrictbenefit+sponsorship withactualartownership/license'),('development_agreement;philanthropy','Eligibledeveloperartsfulfillment/approveddonation; nodoublecreditforfeeanddirectwork')]
        elif id=='open_streets':
            routes=[('metro_open;general_fund','Actualeligibleeventgrantandlocalmatch; datedWestlakeexampleincreative15'),('bid_pb;philanthropy;general_fund','Lawfulroute/merchantbenefit,communityevent andcityoperatingcommitment'),('development_agreement;naming;private_capital','Actuallynegotiatedeventsponsorshipandagencypermits; noverifiedstandardshare')]
        else:
            routes=[('parks_a2016;quimby;general_fund','Onlyeligibleparkcapital andapplicablefeeservice/nexusarea; nonparkservicesnotinferredeligible'),('cdbg;general_fund','Onlyeligiblepublicfacility/service withnationalobjective; lifecost/O&Mseparate'),('development_agreement;philanthropy;private_capital','Securedpublicaccess/siteandactualcapitaldonations/obligations; netO&Mcostnotzero')]
        for rank,(funded,scope) in enumerate(routes,1):add(id,rank,funded,scope)
    # One matched record, expressly not generalized to any other route.
    first=next(x for x in STACKS if x['improvement_id']=='open_streets' and x['rank']==1)
    first['shares_pct']='Westlake2026STAFFREPORTonly: Metro70%,local30%; newprojectsharesNR'
    first['notes']='163611/(163611+70119)=0.70; primaryLADOT2025report AttachmentA. Finalexecutedaward/currentavailabilityNR. Source: https://cityclerk.lacity.org/onlinedocs/2025/25-1457_rpt_dot_12-04-25.pdf'
    # Conservative last pass: a generic technology/category analogy is not
    # intervention-specific program eligibility. Keep such leads out of the
    # proposed funding_ids, and show NR when a third distinct route is missing.
    index={f['id']:f for f in funding}
    for intervention in improvements:
        id=intervention['id'];seen=set();rows=[r for r in STACKS if r['improvement_id']==id]
        available=[f['id'] for f in funding if id in f['eligible_projects'].split(';') and not any(t in f['status'].lower() for t in ['expired','proposed / unverified','no new applications'])]
        used=set()
        for r in rows:
            original=r['funding_ids'].split(';')
            valid=[f for f in original if id in index[f]['eligible_projects'].split(';')]
            unverified=[f for f in original if f not in valid]
            r['unverified_component_leads']=';'.join(unverified) or 'NR'
            if id=='treety':valid=[]
            key=tuple(sorted(valid))
            if not valid or key in seen:
                unused=[f for f in available if f not in used and f not in ['general_fund','private_capital','eifd']]
                valid=unused[:1] if id!='treety' else []
                key=tuple(valid)
                if valid:r['funded_scope']='Only the listed intervention-mapped program is a candidate; precise eligible scope and current award availability must be verified. This is not an awarded stack.'
            if not valid:
                r.update(funding_ids='NR',shares_pct='NR',funded_scope='NR additional distinct program-eligible financing route; no substitute eligibility or percentage invented.',status='NR distinct route not recovered')
            else:
                r['funding_ids']=';'.join(valid);seen.add(key);used.update(valid)
                if unverified:r['notes']+=' ; Unverified component leads are excluded from funding_ids; no automatic funding match.'
    return STACKS
