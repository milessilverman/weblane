"""Assemble source-backed records; CSV authorship is performed by build_tables.mjs."""
import json,re,sys
from pathlib import Path
import data,funding,homeowners,eifd,facts,datasets,notes_and_rankings,stacks

def main():
    data.populate_neighborhoods(); funding.populate(); homeowners.populate(); legal=eifd.populate()
    facts.enrich(homeowners.HOME,funding.FUNDING)
    water,ranked,creative,gaps=notes_and_rankings.populate(); datasets.populate()
    for row in legal['formulas']:
        if row['id']=='f02':
            row['required_inputs']='AIN;RollYear;TaxRateArea;netTaxableValue;isTaxableParcel;Roll_TotalExemption; legally adopted agency-specific base year'
            row['sources']+=' ; https://services.arcgis.com/RmCCgQtiZLDCtblq/arcgis/rest/services/Parcel_Data_2021_Table/FeatureServer/0 | Fields; DataLastEdit2026-01-16; nonspatialtable hasCENTER_LAT/CENTER_LON'
    # Fill missing program identity records without claiming a numeric effect.
    primary=[
      ('atsac','LADOT ATSAC','https://ladot.lacity.gov/projects/transportation-technology/atsac','Real-time/adaptive signal operation',['adaptive_signals','ai_traffic']),
      ('vgi','CPUC Vehicle-Grid Integration','https://www.cpuc.ca.gov/vgi/','VGI definitions/pilots; March2026forum',['v2g','curb_ev']),
      ('vpp25','DOE2025 VPP Liftoff update','https://www.energy.gov/sites/default/files/2025-07/LIFTOFF_DOE_Virtual-Power-Plants%202025_0.pdf','2025report; exact quantitative page NR',['vpp','neighborhood_battery']),
      ('vegetation_epa','EPA roadside vegetation barrier design','https://www.epa.gov/air-research/recommendations-constructing-roadside-vegetation-barriers-improve-near-road-air','Recommendations / design and airflow',['vegetation_buffer','transparent_wall','noise_wall']),
      ('greenroof_epa','EPA green-roof heat-island guidance','https://www.epa.gov/heatislands/using-green-roofs-reduce-heat-islands','Overview; source-specific observed ranges not transferredtoLA',['green_roof','green_wall']),
      ('drone_cv','ChulaVista official DFR program','https://www.chulavistaca.gov/departments/police-department/programs/uas-drone-program','Program launch/history; operator assertions do not prove crime effects',['drone_response']),
      ('sf_red','SFMTA2017 Red Transit Lane evaluation','https://www.sfmta.com/media/9290/download?inline=','Executive Summary printedp2; before2013/after2015',['bus_lane']),
      ('metrolink_score','Metrolink SCORE','https://metrolinktrains.com/','SCOREcapitalprogram; direct program cost table NR',['metrolink_upgrade']),
      ('hsr_maps','CAHSR official maps','https://hsr.ca.gov/project-overview/maps/','System/stationplanning maps; directgeometryNR',['hsr_station']),
      ('parking_cashout','CARB2022 AB2206 Parking Cash-Out','https://ww2.arb.ca.gov/2022-assembly-bill-2206-lee-alex-parking-cash-out-program-chaptered','Chapteredbill program summary',['parking_cashout']),
      ('nav_parent','CityLA NavigateLA REST inventory','https://maps.lacity.org/arcgis/rest/services/Mapping/NavigateLA/MapServer','Parent layer list; selected metadata in Part5',['tree_inventory','recycled_irrigation','cooling_center','shade','public_restroom','drinking_fountain','linear_park','night_market','makerspace','senior_center','outdoor_fitness']),
    ]
    pindex={x['id']:x for x in data.IMPROVEMENTS}
    for sid,name,url,loc,targets in primary:
        data.S(sid,name,url,loc)
        for id in targets:pindex[id]['sources']+=' ; '+data.cite(sid)
    # Aliased catalog entries share a source, not a fabricated new unit cost.
    for id,alias in [('smart_lighting','street_lighting'),('public_restroom','restroom'),('sb79','upzone_transit')]:
        for n in data.SOURCE_IDS.get(alias,[]):pindex[id]['sources']+=' ; '+data.cite(data.prior_source(n))
    for id in ['library','clinic']:
        if id in data.COST_RECORDS:
            number,year,loc,missing,url=data.COST_RECORDS[id]
            pindex[id].update(capex_per_unit='NR fullcost; comparator: '+number,capex_dollar_year=year,capex_includes=missing+' | '+loc,sources=pindex[id]['sources']+' ; '+str(url)+' | '+loc+' | previously recovered; current live verificationNR')
    pindex['bus_lane']['quality_of_life_outcomes']+=' ; SFMTA2017 existing-lane redpaint evaluation: violations−48to55% (range,notCI); allcollisions120→101 between2013and2015; injurycollisions−24%; causalcertaintyC; exactCI/NexposureNR.'
    pindex['light_rail_line']['capex_per_unit']='NR fullresourcecost; Metro2026 ESFV constructionestimate3998000000USD/6.7mi =596716417.91USD/construction-corridor-mile CALCULATED; isolatedstationcostNR'
    pindex['treety']['maturity']='pre-commercial'
    # Add the explicitly requested public-art funding mechanism.
    funding.F('percent_art','LA Percent for Public Art / Arts Development Fee','value capture','LA DepartmentofCulturalAffairs','public_art;cultural_district','Applicablecitycapitalprojects / qualifyingprivatedevelopment; actualowner/applicationroles','CityLosAngeles',src=('percent_art',),award='Citypubliccapitalartsetaside1%; private>=500000USDprojects, feeformulascope-specific; neitheris a universalgrant',status='ordinanceprogram; currentprojectallocationNR',creative='A lawfuldirect-artfulfillmentmaymeetafeerequirement; do notcountfeeandartcostasindependentfunding.')
    for c in creative:
        c['funding_ids']=c['funding_ids'].replace('rule20;','rule20b;')
    # Populate explicit mapping ids. This is an eligibility LEAD list, not an award.
    public_ids=[x['id'] for x in data.IMPROVEMENTS]
    physical=[x for x in public_ids if x not in ['treety','vpp','congestion_pricing','parking_cashout','foot_patrol','violence_interruption','bid','litter','graffiti','encampment','code_enforcement','sb79','hpoz','mills_act','homeownership']]
    for f in funding.FUNDING:
        token=f['eligible_projects']
        if token=='ALL_PHYSICAL_PROJECTS':f['eligible_projects']=';'.join(physical+[x['id'] for x in homeowners.HOME if x['id']!='home_pace'])
        if token=='ALL_PUBLIC_ELIGIBLE_PROJECTS':f['eligible_projects']=';'.join(public_ids)
        if token=='LONG_LIVED_PUBLIC_CAPITAL_AND_ELIGIBLE_HOUSING':
            f['eligible_projects']=';'.join(physical)
            f['stacking_rules']+=' ; AlllistedIDsconditional: mustactuallymeet15-yearcapital/lawfulhousingtest; maintenanceonlynonbondforqualifyingdistrictassets; operationsnoteligible.'
    # Repair metadata and make every unverified route explicit.
    for sid,s in data.SOURCES.items():
        if sid.startswith('fund_'):
            s['access_status']='Agency/operator program route; exactcurrentbalance/awardclause NR unless expresslyidentified; see retrieval_ledger.json'
    ledger_path=data.OUT/'retrieval_ledger.json'
    ledger=json.loads(ledger_path.read_text()) if ledger_path.exists() else {'entries':[]}
    for s in data.SOURCES.values():
        found=[e for e in ledger['entries'] if e['url'].rstrip('/')==s['url'].rstrip('/')]
        s['live_lookup_this_round']='; '.join(sorted(set(e['status'] for e in found))) or 'NR independent live lookup; inherited/source-route or user-context reference'
        s['retrieval_references']=';'.join(sorted(set(e['reference'] for e in found))) or 'NR'
    for row in data.IMPROVEMENTS:
        if row['sources'].startswith('NR primary') and 'http' in row['sources']:
            row['sources']=row['sources'][row['sources'].find(' ; ')+3:]
        if row['sources'].startswith('NR'):
            row['sources']='NR independentlyrecoveredintervention-specificprimarycost/effectrecord; exacttechnologyexists/type mustbeverifiedbeforescreening. Noeffectassigned.'
        matches=[f['id'] for f in funding.FUNDING if row['id'] in f['eligible_projects'].split(';') and not f['status'].startswith('expired')]
        row['funding_sources']=';'.join(matches) or 'NR'
        if row['id']=='treety':row['funding_sources']='NR'
    for row in legal['legal_checklist']:
        sec=row['statute_section'].split('(')[0]
        row['retrieved_mirror_url']='https://codes.findlaw.com/ca/government-code/gov-sect-'+sec.replace('.','-')+'/' if sec in ['53398.52','53398.56','53398.63','53398.66','53398.75','53398.77'] else 'NR currentexactsectionmirror; see sources register/primaryanalyses'
    stack_rows=stacks.build(data.IMPROVEMENTS,funding.FUNDING)
    fund_index={x['id']:x for x in funding.FUNDING}
    for row in stack_rows:
        components=row['funding_ids'].split(';')
        unverified=[x for x in components if x!='NR' and row['improvement_id'] not in fund_index[x]['eligible_projects'].split(';')]
        row['eligibility_status']='conditional; component-specificeligibilityNR: '+','.join(unverified) if unverified else 'mappedcandidateonly; legal/application/ownershipapprovalstillrequired'
        row['sources']=' ; '.join(fund_index[x]['sources'] for x in components if x!='NR') or 'NR verified additionalroute'
        if row['funding_ids']=='NR':row['eligibility_status']='NR additionalverifieddistinctroute'
    # Every unresolved item is enumerable, not only summarized by broad topic.
    for x in data.IMPROVEMENTS:
        fields=[k for k in ['capex_per_unit','capex_dollar_year','capex_includes','annual_om','lifespan_years','home_value_effect_pct','effect_reach_m','effect_years_to_full','effect_grade','effect_CI','effect_N','LA_examples'] if 'NR' in str(x[k])]
        if fields:gaps.append(dict(id='intervention_'+x['id'],topic=x['name'],not_recovered=';'.join(fields),notes='See Part1 exactcells. A partial comparator or qualitativeoutcome does not fill a full-cost/causal-effect field.'))
    for x in homeowners.HOME:
        fields=[k for k in ['typical_cost_LA','cost_dollar_year','resale_value_added','annual_savings','rebates_and_credits','property_tax_effect','permit_needed','payback_years','grade'] if 'NR' in str(x[k])]
        if fields:gaps.append(dict(id='owner_'+x['id'],topic=x['name'],not_recovered=';'.join(fields),notes='See Part2 and cited rebate/tax rules; missing savings/costs are not zero.'))
    for x in datasets.DATA:
        if x['direct_url'].startswith('NR') or 'not' in x['retrieval_status'].lower() or 'unparsed' in x['retrieval_status'].lower() or 'NR' in x['key_fields']:
            gaps.append(dict(id='dataset_'+x['id'],topic=x['dataset'],not_recovered='DirectURL' if x['direct_url'].startswith('NR') else 'Complete feature/body/schema/coverage validation',notes=x['retrieval_status']+'; '+x['notes']))
    for x in funding.FUNDING:
        fields=[k for k in ['annual_amount_available','typical_award_size','match_required','application_cycle_and_deadline','example_LA_awards'] if 'NR' in str(x[k])]
        if fields:gaps.append(dict(id='funding_'+x['id'],topic=x['name'],not_recovered=';'.join(fields),notes='Program authority is not a current award or uncommittedbalance; see Part4 status and eligibility.'))
    for x in stack_rows:
        if x['funding_ids']=='NR':gaps.append(dict(id='route_'+x['improvement_id']+'_'+str(x['rank']),topic='Fundingroute '+x['improvement_id'],not_recovered='Distinct intervention-mapped route at rank'+str(x['rank']),notes='No additional program eligibility, award or percentage invented.'))
    # User-requested exact schemas are unchanged; extra explanations live here.
    notes=[
       dict(id='scope',notes='Research expansion as of2026-11-02; originalV2.1HTML notmodified. A broadcatalog andconditionalfundingleads are not150validatedbenefit/costmodels.'),
       dict(id='schema',notes='Part1/2/4specifiedschemashavenonotescolumn. Theircolumnorder ispreservedexactly; longmethodologyandlimitationsareinthiscompanionnotesCSV and source/eligibilityfields.'),
       dict(id='nr',notes='NR=notrecovered, notzero, notnoeffect. A knownnullresult is statedinwords; unknowncost/CI/N/life/availability are notimputed.'),
       dict(id='grades',notes='A=causalstudyinLA;B=causalsameinterventionelsewhere;C=association/relatedintervention;D=vendor/advocacy/expertestimate. NRwhen noeffectevidence. Gradeisoutcome-specific: schoolfilters haveAeducationevidence, no homepricecoefficient.'),
       dict(id='ci',notes='BRT/ADU approximate95%Waldintervals explicitlyCALCULATEDfromroundedpublishedcoefficients/SE. TheyarenotpublishedbootstrapCIs. Gilraineuseswildclusterbootstrap with28schools, so reportedSEnotconvertedtofalsepreferredCI.'),
       dict(id='not_additive',notes='Model estimates are alternatives. Host-parcel resale, neighbor price, health, safety, tax increment and financing proceeds are different outcomes. Do not sum all benefits or treat capital subsidies as lower resource cost.'),
       dict(id='money',notes='Dollarvintagesarekeptasquoted, withoutguessedinflation. Everymissingquote/awardyear or exactpage/table isNR. Construction,programauthorization,grantaward,feeandfullresourcecost arenotinterchangeable.'),
       dict(id='legacy',notes='Prior-roundcostcomparatorsarecarriedwithscope/retrievalcaveats, oftenpartial ornotnewlyrecovered; theyarenotcurrentfullcostbids. Inheritedmodelassumptions arenotpromotedtoobservations.'),
       dict(id='status',notes='Requestedstatusfieldallowsonlyactive/expiring/proposed, butclosed/reserved/paused/expiredprogramsarestatedtruthfullyinstatus. Noexpiredorfullyreservedrebateisofferedasavailablecash.'),
       dict(id='stacks',notes='Three ranked route slots per intervention are provided. Where three distinct intervention-mapped routes were not recovered, the extra slot is NR. Percentages remain NR except the dated Westlake staff report. Unverified component leads are excluded from funding_ids and must not be automatically offered. No actual financing commitment is claimed.'),
       dict(id='gis',notes='RESTendpointdiscovery andfieldmetadataretrieval do notvalidatefeatures,coverage,lastedit orgeometry. Parent-listedlayersaremarkedassuch. Missingasset ≠missingneed. RequestoutSR4326andtestsampleboundsbeforeingestion.'),
       dict(id='tax',notes='The LaVerne2018example isstatictaxallocation arithmeticonpublishedpotentialnewAV, nottheofficialdynamicforecast/currentAV. Sourceprojects222000USDyear5and2050000USDyear20; static1577587.50USDdoesnotreplicatethese phased/grownforecasts. NetbondcapacityNRwithoutunderwritinginputs.'),
       dict(id='law',notes='CurrentstatutorytextcheckedthroughJan2026mirrorswhereofficialLeginfofetchreturned403; exact2026subsequentchangesandfinalCounty3.106mustbeconfirmedbeforeimplementation. Thispackagecontainscodedarithmeticchecks, notanadoptedIFP.'),
       dict(id='testing',notes='CSVschema/roundtrip/referencechecks andcalculatorunit/incompatibilitychecksperformed. HTMLviewerstatic/codechecks only; localbrowservisualtestunavailableunderanearliersecurityrestriction. No newlyfetchedrawsales/featuredata orindependentlocalDiDclaimed.'),
    ]
    # Additional rows localize unknown evidence and preserve costs as missing.
    for x in data.IMPROVEMENTS:
        notes.append(dict(id=x['id'],notes='Homevalueevidence: '+str(x['effect_grade'])+'; missingcoefficientcannotbeusedtopositivelyrankROI. Fullcostscope,annualupkeep/life/replacement and allconditionaleligibilitymustbereconciledbeforea financedrecommendation.'))
    case_steps=[]
    example=legal.pop('worked_example')
    for k,v in example.items():case_steps.append(dict(input_or_output=k,value=v,units='USD' if any(w in k for w in ['assessed_value','increment']) else 'fraction' if k in ['city_levy_share','county_levy_share','city_commitment','county_commitment','levy'] else 'see value',dollar_year='2018scenario; notinflated',location='LaVerne stationarea',source_url=data.SOURCES['la_verne_2018']['url'],page_table='printedp7AV/participants; printedp8officialphasedforecast',notes='Reproducedsourceinputs/staticderivedcalculation; currentbaseAV,netdebtservice andbondcapacityNR.'))
    # Keep URLs and identifiers exact; improve common place-name spacing only.
    replacements={'LosAngeles':'Los Angeles','LA County':'LA County','CityLA':'City of LA','LaVerne':'La Verne','WestCarson':'West Carson','RedondoBeach':'Redondo Beach','PicoRivera':'Pico Rivera','SanFernando':'San Fernando','SantaMonica':'Santa Monica','VancouverWA':'Vancouver, WA','CityPlants':'City Plants','CityForestCredits':'City Forest Credits','LACounty':'LA County','PublicWorks':'Public Works'}
    def readable(v):
        if not isinstance(v,str) or 'http' in v:return v
        for old,new in replacements.items():v=v.replace(old,new)
        return v
    tables={
      'part1_neighborhood_improvements':(data.P1,data.IMPROVEMENTS),
      'part2_homeowner_actions':(data.P2,homeowners.HOME),
      'part3_eifd_cases':(data.P3CASE,legal.pop('eifd_cases')),
      'part3_legal_checklist':(None,legal.pop('legal_checklist')),
      'part3_formulas':(None,legal.pop('formulas')),
      'part3_district_alternatives':(None,legal.pop('district_alternatives')),
      'part3_worked_example':(None,case_steps),
      'part3_measure_w_rules':(None,water),
      'part4_funding_sources':(data.P4,funding.FUNDING),
      'part4_three_candidate_stacks':(None,stack_rows),
      'part5_datasets':(datasets.HEADERS,datasets.DATA),
      'effect_estimates':(None,facts.EFFECTS),
      'ranked_25_additions':(None,ranked),
      'creative_15_stacks':(None,creative),
      'unverified_and_NR':(None,gaps),
      'notes':(['id','notes'],notes),
      'sources':(None,list(data.SOURCES.values())),
    }
    final={}
    for name,(headers,rows) in tables.items():
        headers=headers or list(rows[0])
        final[name]={'columns':headers,'rows':[{k:readable(r[k]) if k not in ['id','improvement_id','funding_ids','funding_sources','eligible_projects','direct_url','url','source_url'] else r[k] for k in headers} for r in rows]}
    data.OUT.mkdir(parents=True,exist_ok=True)
    (data.OUT/'research_tables.json').write_text(json.dumps({'as_of':'2026-11-02','tables':final,'eifd_example':example},indent=2,ensure_ascii=False))
    (data.OUT/'eifd_example_input.json').write_text(json.dumps(dict(valuation_basis='incremental_taxable_assessed_value',incremental_taxable_av=473750000,eligible_levy=.01,participants=[dict(id='LaVerneCity_2018',levy_allocation_share=.185,committed_fraction=1,is_school_or_eraf=False),dict(id='LACounty_2018',levy_allocation_share=.296,committed_fraction=.5,is_school_or_eraf=False)],dollar_basis='2018sourceforecastscenario; quote-yearbasisnotfullyspecified',notes=example['notes']),indent=2))
    # A self-contained reference snapshot is bundled for reproducible source assembly.
    snapshot={'cost_records':data.COST_RECORDS,'source_ids':data.SOURCE_IDS,'prior_sourcebook_records':data.prior}
    (data.ROOT/'legacy_reference.json').write_text(json.dumps(snapshot,ensure_ascii=False))
    print(json.dumps({name:len(t['rows']) for name,t in final.items()},indent=2))

if __name__=='__main__':main()
