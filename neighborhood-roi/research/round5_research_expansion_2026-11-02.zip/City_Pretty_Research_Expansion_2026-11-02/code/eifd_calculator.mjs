/** Arithmetic screening module. Monetary inputs are USD in one declared basis.
 * NR/null/missing inputs never become zero. No forecast growth, DSCR, borrowing
 * yield, tax allocation, housing reserve or legal sunset is supplied by default.
 */
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const need=(x,label)=>{if(!finite(x))throw new TypeError(`${label}: finite numeric input required (NR is not zero)`);return x;};
const fraction=(x,label)=>{need(x,label);if(x<0||x>1)throw new RangeError(`${label}: expected fraction in [0,1], not percent`);return x;};

export function assessedIncrement(currentTaxableAV,legalBaseTaxableAV){
  return need(currentTaxableAV,'currentTaxableAV')-need(legalBaseTaxableAV,'legalBaseTaxableAV');
}

export function annualAllocation(input){
  if(input.valuation_basis!=='incremental_taxable_assessed_value')throw new TypeError('Use legally derived incremental TAXABLE ASSESSED value, not a market-price uplift');
  const av=need(input.incremental_taxable_av,'incremental_taxable_av');
  const levy=fraction(input.eligible_levy,'eligible_levy');
  if(Math.abs(levy-.01)>1e-12)throw new RangeError('This screen supports the eligible1% property-tax levy only; supply0.01, not1. Other lawful pledged revenues require a separate input.');
  if(!Array.isArray(input.participants)||!input.participants.length)throw new TypeError('At least one consenting participant required');
  const ids=new Set();let shareSum=0;
  const allocations=input.participants.map(a=>{
    if(!a.id||ids.has(a.id))throw new TypeError('Unique participant id required');ids.add(a.id);
    if(a.is_school_or_eraf!==false)throw new TypeError(`${a.id}: school/ERAF exclusion must be explicitly checked`);
    const share=fraction(a.levy_allocation_share,`${a.id}.levy_allocation_share`);
    const pledge=fraction(a.committed_fraction,`${a.id}.committed_fraction`);
    shareSum+=share;
    return {id:a.id,annual_increment_usd:av*levy*share*pledge,effective_fraction_of_eligible_levy:share*pledge};
  });
  if(shareSum>1+1e-10)throw new RangeError('Participating shares exceed entire eligible levy; shares are not agency pledge percentages');
  return {gross_increment_usd:allocations.reduce((s,a)=>s+a.annual_increment_usd,0),allocations,
    notes:'One legally reconciled TRA/agency-base slice only. Sum valid slices after Auditor reconciliation; negative increments are preserved. No automatic parcel-level zero floor.'};
}

export function annualTRAAllocation(records){
  if(!Array.isArray(records)||!records.length)throw new TypeError('Reconciled TRA/agency records required');
  const keys=new Set();const years=new Set();const bases=new Set();const pieces=[];
  for(const r of records){
    if(!r.tra||!r.participant?.id||!Number.isInteger(r.fiscal_year)||!r.legal_base_year||!r.dollar_basis)throw new TypeError('TRA, participant id, fiscal year, legal base year and dollar basis are required');
    const key=[r.tra,r.participant.id,r.fiscal_year].join('|');
    if(keys.has(key))throw new TypeError('Duplicate TRA/agency/fiscal-year record');keys.add(key);
    years.add(r.fiscal_year);bases.add(r.dollar_basis);
    pieces.push({tra:r.tra,participant_id:r.participant.id,legal_base_year:r.legal_base_year,...annualAllocation({...r,participants:[r.participant]})});
  }
  if(years.size!==1||bases.size!==1)throw new TypeError('Do not sum different fiscal years or dollar bases as one annual increment');
  const shares={};for(const r of records){shares[r.tra]=(shares[r.tra]??0)+r.participant.levy_allocation_share;}
  if(Object.values(shares).some(s=>s>1+1e-10))throw new RangeError('Agency allocation shares exceed eligible levy within a TRA');
  return {gross_increment_usd:pieces.reduce((s,r)=>s+r.gross_increment_usd,0),pieces,notes:'Agency-specific legally derived incremental AV required. No universal shared base year or parcel-level zero floor.'};
}

export function screenLevelDebt(input){
  const required=['yield','term_years','issuance_cost_usd','funded_reserve_usd','capitalized_interest_usd','other_closing_deductions_usd','dollar_basis','legal_sunset_year'];
  const missing=required.filter(k=>input[k]===null||input[k]===undefined||input[k]==='NR');
  if(!Array.isArray(input.cashflows)||!input.cashflows.length)missing.push('cashflows');
  else input.cashflows.forEach((x,i)=>{for(const k of ['year','net_pledged_revenue_usd','dscr'])if(x[k]===null||x[k]===undefined||x[k]==='NR')missing.push(`cashflows[${i}].${k}`);});
  if(missing.length)return {gross_par_usd:'NR',spendable_capital_usd:'NR',missing_inputs:missing};
  const yield_=need(input.yield,'yield');if(yield_<0)throw new RangeError('Negative yields need a separately modeled debt structure');
  const term=need(input.term_years,'term_years');if(!Number.isInteger(term)||term<1)throw new RangeError('term_years must be a positive integer');
  if(input.cashflows.length!==term)throw new RangeError('Supply one stressed net-revenue/coverage record per repayment year');
  const sunset=need(input.legal_sunset_year,'legal_sunset_year');
  const years=new Set();
  let allowableDS=Infinity;
  for(const c of input.cashflows){
    need(c.year,'cashflow.year');if(!Number.isInteger(c.year)||years.has(c.year))throw new RangeError('Unique integer repayment years required');
    years.add(c.year);if(c.year>sunset)throw new RangeError('Repayment cashflow extends beyond supplied legal sunset');
    const net=need(c.net_pledged_revenue_usd,'net_pledged_revenue_usd');const dscr=need(c.dscr,'dscr');
    if(dscr<1)throw new RangeError('Coverage below1 is not a fully covered screening case');
    allowableDS=Math.min(allowableDS,net/dscr);
  }
  const sorted=[...years].sort((a,b)=>a-b);for(let i=1;i<sorted.length;i++)if(sorted[i]!==sorted[i-1]+1)throw new RangeError('Repayment years must be contiguous for a level annuity');
  const deductions=['issuance_cost_usd','funded_reserve_usd','capitalized_interest_usd','other_closing_deductions_usd'].reduce((s,k)=>{const v=need(input[k],k);if(v<0)throw new RangeError('Closing deductions cannot be negative');return s+v;},0);
  const ds=Math.max(0,allowableDS);
  const factor=yield_===0?term:-Math.expm1(-term*Math.log1p(yield_))/yield_;
  const par=ds*factor;
  return {max_level_annual_debt_service_usd:ds,gross_par_usd:par,spendable_capital_usd:Math.max(0,par-deductions),closing_funding_shortfall_usd:Math.max(0,deductions-par),missing_inputs:[],
    notes:'Level-debt-service screen; not an underwriting commitment. Net revenues must already deduct lawful maintenance/admin/housing, collection lags and senior liens. Capital eligibility and actual legal term are external inputs.'};
}

export function reviewFundingStack(ids,context={}){
  const errors=[];const holds=[];
  const set=new Set(ids);
  if(set.has('scw_trade')&&['scw_regional','scw_municipal','scw_trp'].some(x=>set.has(x)))errors.push('SCWP funding at any stage is incompatible with SCWP tradable credits for the same improvement');
  if(set.has('scw_trade')){
    if(context.seller_is_municipality===true)errors.push('Municipalities excluded as credit-trading sellers');
    if(context.has_any_scwp_funding===true)errors.push('Project has SCWP funding, so cannot generate tradable credits');
    if(context.seller_is_tax_exempt!==true)holds.push('Verify tax-exempt seller parcel and runoff provenance');
    if(context.same_municipality_and_watershed!==true)holds.push('Verify buyer/seller municipality AND watershed match');
    if(context.has_any_scwp_funding!==false)holds.push('Verify no SCWP money at planning,design,construction or O&M stage');
  }
  for(const x of ['fed25c','fed25d','fed30c'])if(set.has(x))errors.push(`${x}: expired for a new late2026 installation`);
  for(const x of ['heehra','sce_charge_ready','mills_act'])if(set.has(x))holds.push(`${x}: new applications/reservations unavailable or paused in checked program; confirm an existing reservation or other jurisdiction`);
  if(set.has('prop4')&&['urban_greening','tcc'].some(x=>set.has(x)))holds.push('Prop4 umbrella and its subprogram may be the same dollars; reconcile separate awards');
  if(set.has('fed48e')&&set.has('solar_ppa'))holds.push('Identify the actual tax owner; public elective pay and private PPA credits cannot be claimed twice');
  if(set.has('cfc'))holds.push('Verify carbon rights, additionality, permanence and exclusive claims under current protocol');
  return {errors,holds,quantified_shares:'NR unless a matched executed project funding plan is supplied'};
}
