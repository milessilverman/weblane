import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook} from '@oai/artifact-tool';
const out=process.argv[2];if(!out)throw new Error('Output directory required');
const data=JSON.parse(await fs.readFile(path.join(out,'research_tables.json'),'utf8'));
const wb=Workbook.create();const writes=[];
for(const [name,t] of Object.entries(data.tables)){
  const sheet=wb.worksheets.add(name.slice(0,31));
  const rows=[t.columns,...t.rows.map(r=>t.columns.map(k=>r[k]))];
  for(const row of rows)for(const v of row)if(v===undefined||v===null||typeof v==='object')throw new Error('Non-scalar or missing table field');
  const safe=rows.map(row=>row.map(v=>typeof v==='string'&&v.startsWith('=')?"'"+v:v));
  sheet.getRangeByIndexes(0,0,rows.length,t.columns.length).values=safe;
  writes.push({sheet,name,rowCount:rows.length,colCount:t.columns.length});
}
wb.recalculate();
const inspections=[];
for(const {sheet,name,rowCount,colCount} of writes){
  const values=sheet.getRangeByIndexes(0,0,rowCount,colCount).values;
  const csv=values.map(row=>row.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n')+'\r\n';
  await fs.writeFile(path.join(out,name+'.csv'),csv,'utf8');
  if(['part1_neighborhood_improvements','part2_homeowner_actions','part3_worked_example','part4_funding_sources','part5_datasets'].includes(name)){
    inspections.push({name,inspection:await wb.inspect({kind:'region',sheetId:sheet.name,range:'A1:C3',maxChars:1200,tableMaxRows:3,tableMaxCols:3,tableMaxCellChars:110})});
  }
}
await fs.writeFile(path.join(out,'artifact_table_checks.json'),JSON.stringify({authoring:'@oai/artifact-tool',tables:writes.map(x=>({name:x.name,rows:x.rowCount-1,columns:x.colCount})),inspections},null,2));
console.log(JSON.stringify({csvFiles:writes.length,rows:writes.reduce((s,x)=>s+x.rowCount-1,0)}));
