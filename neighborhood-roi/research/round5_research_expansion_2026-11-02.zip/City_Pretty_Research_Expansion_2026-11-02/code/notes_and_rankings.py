from data import SOURCES,cite
WATER=[];RANKED=[];CREATIVE=[];GAPS=[]

def populate():
    def W(id,rule,value,units,source,locator,notes):
        WATER.append(dict(id=id,rule=rule,value=value,units=units,geography='LACFCD / applicableSCWPwatershed',vintage='2026call unlessotherwiseidentified',source_url=SOURCES[source]['url'],page_table=locator,notes=notes))
    W('w01','Programrevenueallocation','Regional50;Municipal40;District10','percent of programrevenue, NOT projectcost','scw_muni','MunicipalProgramallocation','AnnualavailabledollarsNR; Regionalcompetitive/Municipalcityplan roles differ.')
    W('w02','Regionalapplicantpath','Feasibilitystudy→WASC→scoring→SIPapproval→transferagreement','process','scw_fsg','pp2–4 requirements','Nonmunicipalproponent needsmunicipalsupport/O&Mconcurrence; TRPcanpreparestudy.')
    W('w03','Originalrubriceligibility','60','minimumscorepoints','scw_fsg','p11 ExhibitA','2026pilotchoice: use originaloradaptedrubric, notcombinedmaximums.')
    W('w04','Minimumprojectarea','NR blanketacreagefloor','acres','scw_supp','Applicationguidance','Dryweatherdrainage-area scorebands are notminimumprojectsize.')
    W('w05','Stormwaterdesign','85thpercentile24-hourstorm; WMS/HydroCalc guidance','modeledstorage/runoff','scw_supp','pp13–15','Quantifycatchment,imperviousness,soils,inflow,bypass; canopycountaloneinsufficient.')
    W('w06','Annualsupply','Atleast20yearshydrology','annualaverageacre-feet','scw_fsg','p8 section3.2','Avoid downstreamdoublecapture; designstormstorage ≠annualsupply.')
    W('w07','Pollutionbenefit','10yearmodelcomparison','influent/effluent concentration/load/exceedances','scw_fsg','pp6–7 section3.1','SpecifyTMDLpollutants and BMPperformance; no universaltreecapturecoefficient.')
    W('w08','Naturebasedbenefit','Good/better/best','rubric; exactprojectpointsrequireevaluation','scw_interim','p51','Retain/restorehabitat,removeimperviousarea,appropriatevegetation; treecountnotautomaticcredit.')
    W('w09','Lifecyclebudget','Concept→design→land→permits→build→O&M/monitoring','eligibleprojectbudgetcomponents','scw_fsg','p3 requirement6','SCWPguidelineexcludesend-of-life dismantling/replacement; CityPrettymustaddthemseparately.')
    W('w10','Taxcredittradingeligibility','Taxexemptseller; municipalitiesexcluded','entity/parcelrule','scw_trade','printedpp2–3 / PDFpp3–4','NoSCWPfunding atANYstage, includingO&M;othermunicipalfundingcase-by-case.')
    W('w11','Tradableunit','1TCTU=1USDannualassessmentcredit','taxoffset; negotiatedcashpriceNR','scw_trade','printedpp3–5','Same municipalityANDwatershed; approvedprojects/engineerverificationrequired; buyerbenefitnotfullsellerrevenue.')
    W('w12','Tradingduration','2','yearcertificationcycle','scw_trade','printedpp4–5','Buyerclaimsperyear; recertificationnotperpetuity; currentnextdeadlineNR.')
    W('w13','Treetyidentity','In-progressuserprototype; publicservice/agencyroleNR','verificationstatus','treety_identity','Prioruserdescription2026-10-30','Separateprototypeidentity fromMeasureWstatutoryeligibility; noverifiedauthorizationorfees.')
    ranked=[
      ('ab8_af91','TRA-level AB8 factors','Prevents capturing school taxes or all1%levy for anEIFD; corefinancialinput.'),
      ('av_sv11','Taxable assessedvalue/base-year reconciliation','Makes taxincrement forecasts auditable and distinct from marketvalue.'),
      ('ces5_csv','CES5 plus official2026DAC designation','Updates environmentalpriority and fundingeligibility without guessingfromoldpercentiles.'),
      ('scw_trade','MeasureW credittrading exclusion rules','Blocks incompatible grant-plus-creditstacks; opens a conditional nonmunicipalroute.'),
      ('eifd','Current EIFD term/bond/maintenance rules','Avoids old55%bondvote, wrongsunset and bond-fundedoperations.'),
      ('fed25d','Expired federal homeowner/charger credits','Removes nonexistent late2026subsidies from ownerpayback.'),
      ('heehra','Actual rebate reservations/status','Separates authorized funding from money stillavailable to a newapplicant.'),
      ('home_adu','Host-parcel ADU estimate withmodelN/SE','Adds a measuredLA association while preventing spillovermisuse.'),
      ('brt','Same-intervention BRT estimates withcalculatedCI','Replaces an unqualifiedrange with model-specificN/SE andwalknetworkreach.'),
      ('bus_lanes','Existing bus-lane GIS withoperationhours','Defines treatedsegments; installhistory stillneedsprojectrecords.'),
      ('dwp_oh','LADWP overhead/underground layers','Allows an actualutilityinventoryscreen, aftergeometry/coveragevalidation.'),
      ('school_filters','LA classroom air-filter causalstudy','Adds localeducationevidence without inventing a homepriceconversion.'),
      ('streetlights','Streetlight geometry and lamp-code audit','Detects an implausible advertisedextent before producing falsecoverage.'),
      ('la_sb79','Actual localSB79 phasedordinances','Prevents blanket countywide half-mileupzoning assumptions.'),
      ('funding_stacks','Three conditional fundingroutes perintervention','Organizes leads while leaving all unrecovered percentagesNR.'),
      ('cfc','Urban-tree carbon projectrights/protocols','Distinguishes creditrevenue,verification/permanencecosts and ownership.'),
      ('schoolyard_green','Schoolyard scope-specificcosts','Avoids treating a broadcampusmodernizationpackage as puregreeningunitcost.'),
      ('bid','BID polygon plusactualassessmentbase','Separates assessedparcel acres from publicstreetarea and annualopex.'),
      ('open_streets','Actual Metro/localmatchingrecord','A rare documented70/30example, limited to its eventbudget.'),
      ('public_solar','Publicsolar/electivepay vsPPAownership','Keeps roofcoating and trees out of the clean-electricitycredit.'),
      ('home_turf','Preapprovedwaterrebate rules','Avoids promising payment after an owner startsworkwithoutreservation.'),
      ('mural_subset','Officialmuralregistrygap andbad-coordinateflag','Prevents a limitedresearchlayer or Florida dataset from masqueradingasLAinventory.'),
      ('rail_station','Gold/Expo peer-reviewedheterogeneity evidence','Supports searching modeltables rather than imposing one universalpremium.'),
      ('grants_prop68','Award/contract/payment/completion distinction','Improves costhistory and treatmentdates; an awardalone isnotas-built.'),
      ('cvv_la','LA-specific remodelscopes gradedD','Useful ownerbudgetcomparators with no claim of causalsalepriceROI.'),
    ]
    for rank,(id,name,why) in enumerate(ranked,1):RANKED.append(dict(rank=rank,id=id,addition=name,why_it_improves_accuracy=why,notes='Qualitativeimplementationpriority; not a measuredbenefit/costranking.'))
    creative=[
      ('schoolyard_green','Tax-exempt schoolyardstormwater project: philanthropy/privatecapital upfront plus approvedSCWPcredittrading aftercompletion, with noSCWPfunds and nonmunicipalsellerstatus; sharesNR.','scw_trade;philanthropy;private_capital'),
      ('green_street','Engineered greenstreet: SCWPRegional +SCWPMunicipal +eligiblelocalcapital for separateapproved costs; sharesNR and tradablecredits excluded.','scw_regional;scw_municipal;general_fund'),
      ('street_trees','Streettreetrenches: eligibleCALFIREUCF establishment +SCWPMunicipal stormwaterwork +applicabletreein-lieufees, with distinctinvoices and verifiedmaintenance; sharesNR.','calfire_ucf;scw_municipal;tree_fee'),
      ('resilience_hub','Public resiliencehub: applicableCECaward +eligibleownedsolar/storage48Eelectivepay +lawfulcapitalappropriation, with operatingfunds budgeted separately; sharesNR.','cec;fed48e;general_fund'),
      ('public_solar','Publicparking solar: negotiatedPPA/groundlease +assignedRECs +eligiblechargerLCFSrevenue, with tax/attributeownership and netcosts reconciled; sharesNR.','solar_ppa;rec_market;lcfs'),
      ('bus_shelters','Shelters: STAPconcessionobligations +eligibleMetroLocalReturn +separatelyapprovedsolar/chargingpackage, without treating advertising or maintenance as free; sharesNR.','stap;prop_a;private_capital'),
      ('rail_station','Stationdistrict: Metrojointdevelopmentgroundlease +legallypledgedEIFDincrement +eligiblehousing/first-last-mileaward, separating existinglandvalue from projectcausation; sharesNR.','joint_development;eifd;ahsc'),
      ('clinic','Eligible low-incomecommunityclinic: NMTCthroughallocatedCDE +Section108debt +committedowner/philanthropiccapital, with repayment/fees and no doubledollar reimbursement; sharesNR.','nmtc;section108;philanthropy'),
      ('pocket_park','Brownfieldpocketpark: EPAeligibleassessment/cleanup +parkfee/MeasureAparkcapital +separateSCWPdrainagescope after liability and sitecontroltests; sharesNR.','epa_brownfield;parks_a2016;scw_regional'),
      ('open_streets','WestlakePark-to-Park2026 staffreport documents163611USDMetro +70119USDlocal =233730USD, or70%/30% for that proposed eventbudget, not a universal programmatch.','metro_open;general_fund'),
      ('public_art','Private redevelopment mural: applicableLAArtsDevelopmentFee/direct-artfulfillment +BIDspecial-benefitbudget +sponsorship, subject topublic-artownership and ordinance rules; sharesNR.','percent_art;bid_pb;naming'),
      ('utility_trail','UtilityROWtrail: owner-approvedeasement +eligibleATP/transportationaward +conservancyhabitatcomponent, keeping utilityoperationalrights and componentcosts explicit; sharesNR.','atp;wcb;development_agreement'),
      ('affordable_housing','AffordableTOD: allocatedLIHTC +AHSCeligibleaccessinfrastructure +lawfulULA/othercityhousinggap, with separatecosts and no assumption that allrounds areopen; sharesNR.','lihtc;ahsc;ula'),
      ('home_microgrid','Qualifiedincome home storage: reservedSGIP +compatibleCPAutilityprogram +ownerfinance after utility/taxownership review, with expired25Dexcluded; sharesNR.','sgip;cpa;private_capital'),
      ('undergrounding','Qualifyingundergroundconversion: actualSCE Rule20credits +agency/developer/ownerpayment for excluded work, withLADWP treatedunderitsownrules; eligible20Btariffcost-share20–40%, fullprojectsharesNR.','rule20;development_agreement;private_capital'),
    ]
    for rank,(id,sentence,ids) in enumerate(creative,1):CREATIVE.append(dict(rank=rank,improvement_id=id,funding_ids=ids,sentence=sentence,notes='Candidate route except expressly dated example; eligibility, availability and agreements remain required.'))
    gaps=[
      ('Fullcosts','FullLA design+land+utilities+labor+contingency cost, annualO&M, measuredlife and replacement for most emergingtypes','NR; comparators expresslypartial; no guessedzeros.'),
      ('Effects','Causal homepriceeffects/95%CI/N for mostnewtypes incl5G,vertiports,VPP,noise/ALPR/dronecameras,padel,publicart,misting,tinyforests','NR; generictechnologyexistence doesnotvalidate a pricecoefficient.'),
      ('Localrail','ExactGold/Expo modelcoefficients,N/CI; KLine/Foothilllocalcausalcoefficients; currentstation-specificfullcosts','NR fulltables/data; licensedDataQuickmicrodata.'),
      ('Trailprices','Causal LA ParktoPlaya/Ballonaeffects; exact606/BeltLine/Indianapoliscausal estimates andCI/N','NR; descriptive606appreciationnotimported.'),
      ('Rawlocalestimation','NewindependentLA hedonic/DiD from rawsales and completiondates','Not performed inthis researchpackage; priorapp estimatesnotreplicated.'),
      ('EIFDdatabase','Complete currentcensus of LA EIFDs and finalIFPs/TRAlegalpolygons/pledgeresolutions/issuedbondpar','NR completeinventory; formationintent and PFAappointment arenotfinalfunding.'),
      ('EIFDlegal','AB1717 as EIFDamendment; finaladopted2025/26CountyPolicy3.106redline; currentallalternative-districtvote/rateclauses','AB1717EIFDclaimunverified; currentpolicyfinalversionNR; district-specificlegalreviewrequired.'),
      ('EIFDnumericbondexample','FullydocumentedcurrentLAneighborhoodbaseAV+AB8+datedbondrate/DSCR/term/closingdeductions','NR; onlyhistoricalLaVerne2018annualincrementexample fullynumeric; bondcapacitywithheld.'),
      ('TaxGIS','Direct2026TRAgeometry; unifiedEIFD/CFD/LLDcurrentREST; selectedroll/AF91/SV11exactfilefields','NR orarchiveunparsed; officialdownloadlinksprovidedwithoutinventedfieldnames.'),
      ('Fundingpercentages','Three actuallyawarded financeplans perintervention with fullshares','NR except datedreportedcomparators; threecandidate routesprovided, not fabricated75/15/10splits.'),
      ('Currentfunding','Uncommittedbalances/open2027rounds for manyfederal,state/localprograms; actualLAprogramawards forallfundingrows','NR unless expresslyrecovered; activeauthorityisnotcashavailability.'),
      ('Treety','Publiclaunchedcompany/service,fees,customers,authorityoragreementtoadministerSCWP','Prototypeidentity/domainrecovered fromusercontext; publicfetchfailed; remainingclaimsNR.'),
      ('Neighborly','CurrentoperatingNeighborlycivicbondplatform','NR; do not assumeformerlyknownplatform available.'),
      ('Biodiversity','Generaltradableurban-treebiodiversitycreditprogram andrealizedLAprices','NR; approvedmitigationbankcreditsexistbutarenotinterchangeablewithvoluntaryneighborhoodcredits.'),
      ('WaymoRevenue','StandingWaymoROWlease/revenue program forLAneighborhoods','NR verifiedprogram; proposedcontractideaonly.'),
      ('Mobilityfee','SinglecountywideMobilityPlanfeeavailabletoallimprovements','NR verifiedprogram; enactedlocalnexus-basedfeesmustbeidentified.'),
      ('Telecomdata','Anonymousaddress-levelFCCavailability+Fabric; currentLA5GdeploymentAPI; exactpoleleasedollars','NR unrestrictedpublicdownload; token/FRN/licensing andassetcontracts matter.'),
      ('Utilitydata','All-SCE overhead/underground distributionGIS; legalunusedROWrights; LADWPconversioncompletioncohorts','NR publiccompletefiles; DWPpublicmetadataonlyrequirescoveragecheck.'),
      ('SensorGIS','PublicspeedcameraactivationAPI,WaymoversionedGeoJSON,correctBSLstreetlightgeometries/lampcodedictionary','NR functionalbulkvalidation; BSLadvertisedextentfailsLAplausibilityscreen.'),
      ('Culturedata','OfficialcurrentDCAmuralbulkregistry andcompleteculturalassets','NR; 2017researchsubsetincompleteandcoordinateerrors; FloridaCityMuralsnotused.'),
      ('Projecthistory','DirectSCWP/TCC/ATP/Prop68/CityPlantscohortAPIs with actualcompletiondates,paidcostsandO&M','NR exactbulkURLs/schemas; officialprogram/portalroutesanddatarequestspecsprovided.'),
      ('Owneroutcomes','LA scope-matchedADU/solar/battery/microgridbidcosts, annualsavings/insurancepremiumchange, financingrates','NR; no simplepaybackcomputedfrommissinginputs orindustryresaleprojection.'),
      ('Access','LivefeaturedownloadandrawZIPbodyvalidation foralllinkedservices','Onlyretrievedmetadata/indexlinksareclaimed; fetchfailures andredirect-limiteddownloads marked; noofflinecopyoflicenseddata.'),
    ]
    for rank,(topic,missing,notes) in enumerate(gaps,1):GAPS.append(dict(id=f'gap{rank:02}',topic=topic,not_recovered=missing,notes=notes))
    return WATER,RANKED,CREATIVE,GAPS
