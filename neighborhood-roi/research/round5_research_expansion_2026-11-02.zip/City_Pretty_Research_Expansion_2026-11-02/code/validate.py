import csv,json,re,hashlib,os
from pathlib import Path
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parent;OUT=Path(os.environ.get('CITY_PRETTY_RESEARCH_OUT',str(ROOT.parents[1]/'outputs/city_pretty_expansion_20261102' if (ROOT.parent/'city_pretty_v2').exists() else ROOT.parent/'data')))
data=json.loads((OUT/'research_tables.json').read_text());tables=data['tables']
checks=[]
def ok(test,label):
    assert test,label
    checks.append(label)
for name,t in tables.items():
    with (OUT/(name+'.csv')).open(newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f);rows=list(reader)
    ok(reader.fieldnames==t['columns'],name+' exactcolumnorder')
    ok(len(rows)==len(t['rows']),name+' rowcount')
    for expected,actual in zip(t['rows'],rows):
        ok(set(actual)==set(t['columns']),name+' rowshape')
        for k,v in expected.items():
            # CSV authored through workbook values; compare scalar data exactly,
            # with numeric equality where JS/Python scalar stringification differs.
            if isinstance(v,(int,float)):
                ok(abs(float(actual[k])-v)<=max(1e-12,abs(v)*1e-14),name+' numericroundtrip')
            else:ok(actual[k]==str(v),name+' textroundtrip')
    if 'id' in t['columns']:ok(len({r['id'] for r in rows})==len(rows),name+' uniqueids')
p1=tables['part1_neighborhood_improvements']['rows'];p2=tables['part2_homeowner_actions']['rows'];fund=tables['part4_funding_sources']['rows'];fids={r['id'] for r in fund};pids={r['id'] for r in p1+p2}
ok(all(set(r['eligible_projects'].split(';'))<=pids for r in fund),'All fundingprojectreferences resolve')
ok(all(r['funding_sources']=='NR' or set(r['funding_sources'].split(';'))<=fids for r in p1),'All interventionfundingreferences resolve')
ok(all(set(r['funding_ids'].split(';'))<=fids for r in tables['creative_15_stacks']['rows']),'All creative fundingreferences resolve')
stacks=tables['part4_three_candidate_stacks']['rows']
ok(all(sorted(r['rank'] for r in stacks if r['improvement_id']==x['id'])==[1,2,3] for x in p1),'Exactly threecandidate routes perintervention')
ok(all(r['effect_grade'] in ['A','B','C','D','NR'] for r in p1),'Effectgradeenum')
ok(all(r['scale'] in ['block','corridor','district','regional'] for r in p1),'Scaleenum')
ok(all(r['maturity'] in ['proven','emerging','pilot','pre-commercial','NR'] for r in p1),'Maturityenum')
for r in stacks:
    ids=set(r['funding_ids'].split(';'))
    ok(not('scw_trade' in ids and ids&{'scw_regional','scw_municipal','scw_trp'}),'No incompatible SCWPcredit stack')
    ok(not(ids&{'fed25c','fed25d','fed30c'}),'No expiredfederalcredit in candidate routes')
html=(OUT/'City_Pretty_Research_Expansion.html').read_text()
class Parser(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.srcs=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        if tag=='script' and 'src' in a:self.srcs.append(a['src'])
p=Parser();p.feed(html)
ok(len(p.ids)==len(set(p.ids)),'HTMLuniqueids')
ok(not p.srcs,'SelfcontainedHTMLnoexternalscripts')
ok('width=device-width,initial-scale=1' in html and '@media(max-width:700px)' in html,'MobileviewportandresponsiveCSSpresent')
ok('showModal()' in html and 'aria-label="Close record"' in html,'Recorddialoglabelsandnativeescapehandling')
scripts=re.findall(r'<script type="module">(.*?)</script>',html,flags=re.S)
ok(len(scripts)==1,'Oneinlineapplicationmodule')
(ROOT/'html_module_check.mjs').write_text(scripts[0])
source_urls=[r['url'] for r in tables['sources']['rows']]
ok(not any(re.search(r'X-Amz-|Signature=',u,re.I) for u in source_urls),'No signeddownloadURLs in sourceregister')
report={
    'checks_passed':len(checks),'tables':len(tables),'rows':sum(len(t['rows']) for t in tables.values()),
    'interventions':len(p1),'homeowner_actions':len(p2),'funding_sources':len(fund),'candidate_routes':len(stacks),
    'dataset_records':len(tables['part5_datasets']['rows']),
    'dataset_records_with_nr_direct_url':sum(r['direct_url'].startswith('NR') for r in tables['part5_datasets']['rows']),
    'interventions_with_numeric_percent_price_effect':sum(isinstance(r['home_value_effect_pct'],(int,float)) for r in p1),
    'routes_with_component_eligibility_not_recovered':sum('component-specificeligibilityNR' in r['eligibility_status'] for r in stacks),
    'route_slots_with_no_additional_verified_route':sum(r['funding_ids']=='NR' for r in stacks),
    'notes':['No rawbulkdatareingestion or newlyestimatedLAcausaleffects claimed.','Browservisualverification notrun; staticHTMLandmodulechecks only.','Unknowncosts/effects/lifecycles/eligibility remainNR.'],
    'file_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.suffix in ['.csv','.html']}
}
(OUT/'validation_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='file_sha256'},indent=2))
