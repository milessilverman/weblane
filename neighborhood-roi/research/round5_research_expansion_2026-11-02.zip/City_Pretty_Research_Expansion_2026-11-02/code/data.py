"""Research records, as of 2026-11-02. NR never means a zero effect or zero cost."""
import json,sys,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=Path(os.environ.get('CITY_PRETTY_RESEARCH_OUT',str(ROOT.parents[1]/'outputs/city_pretty_expansion_20261102' if (ROOT.parent/'city_pretty_v2').exists() else ROOT.parent/'data')))
P1='id|name|category|scale|maturity|capex_per_unit|unit|capex_dollar_year|capex_includes|annual_om|lifespan_years|home_value_effect_pct|effect_reach_m|effect_years_to_full|effect_grade|effect_CI|effect_N|effect_study_location|negative_effects|quality_of_life_outcomes|fits_where|data_needed_to_site_it|LA_examples|funding_sources|sources'.split('|')
P2='id|name|category|typical_cost_LA|cost_dollar_year|resale_value_added|value_source|annual_savings|rebates_and_credits|property_tax_effect|permit_needed|payback_years|grade|sources'.split('|')
P4='id|name|type|administrator|annual_amount_available|typical_award_size|match_required|eligible_projects|eligible_applicants|eligibility_geography|stacking_rules|application_cycle_and_deadline|status|example_LA_awards|creative_uses|sources'.split('|')
P3CASE='name|city|year formed|acres|base_AV|45-yr increment projection|county share %|city share %|projects|bonds|source'.split('|')
SOURCES={}
def S(id,name,url,locator='HTML section; page/table NR',status='retrieved or indexed this round',notes=''):
 SOURCES[id]=dict(id=id,name=name,url=url,locator=locator,catalogued_as_of='2026-11-02',access_status=status,notes=notes)
 return id
def cite(*ids):
 return ' ; '.join(f"{i}: {SOURCES[i]['name']} | {SOURCES[i]['url']} | {SOURCES[i]['locator']} | {SOURCES[i]['access_status']}" for i in ids)

S('scw_call','SCWP2026 Call for Projects','https://safecleanwaterla.org/call-for-projects/','Key Dates; Infrastructure Program Projects')
S('scw_fsg','SCWP November2025 Feasibility Study Guidelines','https://safecleanwaterla.org/content/uploads/2025/12/Feasibility-Study-Guidelines-20251119.pdf','pp.6–9 requirements; pp.11–12 ExhibitA rubric')
S('scw_supp','SCWP April2026 Supplemental Guidance','https://safecleanwaterla.org/content/uploads/2026/04/Supplemental-Guidance-to-Support-FSG-20260430_.pdf','pp.13–15 hydrology; p.33 nature-based solutions; AttachmentA/B scoring pilot')
S('scw_interim','SCWP2025 Interim Guidance','https://safecleanwaterla.org/content/uploads/2025/05/SCWP-2025-Interim-Guidance-20250509.pdf','pp.43,51 community benefits and good/better/best')
S('scw_muni','SCWP Municipal Program','https://safecleanwaterla.org/about-us/municipal-program/','Annual Plans; funding allocation')
S('scw_oct26','SCWP October2026 implementation update','https://safecleanwaterla.org/implementation-update-october-2026/','Regional Program2026 call')
S('scw_credit','SCWP parcel credits and credit trading','https://safecleanwaterla.org/what-we-do/tax-information-forms-tools/','How tax is calculated; Credit Trading Program')
S('scw_credit_pdf','SCWP parcel credit procedures','https://safecleanwaterla.org/content/uploads/2019/09/Credit-Program-Procedures-and-Guidelines-20190917-FINAL.pdf','Community Investment Credit; Additional Activities Credit; exact PDF page NR')
S('scw_trade','SCWP Credit Trading Procedures, Dec2024','https://safecleanwaterla.org/content/uploads/2025/01/Credit-Training-Program-Procedures-and-Guidelines-Final.pdf','14-page PDF; sections and page locators in Part3 measure_w_rules')
S('scw_trade_receipt','SCWP trading transaction guidelines','https://safecleanwaterla.org/content/uploads/2025/10/20250602-CTP-Purchase-Agreement-and-Receipt-Guidelines-Clean-1.pdf','pp.1–3 Purchase Agreement / Receipt')
S('cfc','City Forest Credits protocols','https://www.cityforestcredits.org/carbon-credits/carbon-protocols/','Afforestation/Reforestation Protocol; qualification and registry','operator primary source; financial/benefit claims are D')
S('silva','DeepRoot Silva Cell engineer guidance','https://www.deeproot.com/products/silva-cell/engineers/','Determine budget pricing','vendor primary source; D; price year NR')
S('cityplants','City Plants programs','https://www.cityplants.org/our-programs/','Yard Trees; Street Trees')
S('cityplants_faq','City Plants FAQ','https://www.cityplants.org/faq/','Tree limit; establishment and permits')
S('irs_end','IRS OBBB termination FAQ','https://www.irs.gov/newsroom/faqs-for-modification-of-sections-25c-25d-25e-30c-30d-45l-45w-and-179d-under-public-law-119-21-139-stat-72-july-4-2025-commonly-known-as-the-one-big-beautiful-bill-obbb','Q1 termination table; Q7 installation timing')
S('irs_pay','IRS elective-pay FAQ','https://www.irs.gov/credits-deductions/elective-pay-and-transferability-frequently-asked-questions-elective-pay','Q13 underlying credit eligibility; Q26 earned-credit timing')
S('irs48','IRS Notice2025-42 in IRB2025-36','https://www.irs.gov/irb/2025-36_IRB','Notice2025-42 section2.02 and construction rules')
S('dwp_hp','LADWP Consumer Rebate Program','https://www.ladwp.com/residential-services/assistance-programs/consumer-rebate-program','Heat Pump HVAC and HPWH tables','retrieved; old federal-credit text conflicts with newer IRS termination—IRS controls')
S('dwp_ev','LADWP residential charger FAQ','https://www.ladwp.com/residential-services/programs-and-rebates-residential/electric-vehicles/residential-ev-charger-rebate-program-faqs','How much are the rebates? table; actual-cost ceiling')
S('sce_home','SCE Charge Ready Home','https://evhome.sce.com/eligibility','Rebate Types; Resident Eligibility')
S('sce_ready','SCE Charge Ready','https://www.sce.com/business/smart-energy-solar/charge-ready','Program Application Deadline','indexed current page: no new applications; agreements by Dec31 2026')
S('sgip','CPUC SGIP','https://www.cpuc.ca.gov/sgip','Residential Solar and Storage Equity budget/rate table')
S('heehra','TECH HEEHRA program administrator','https://techcleanca.com/incentives/heehrarebates/','Fully Reserved; stacking restrictions; dates Feb24 and Sep1 2026')
S('tech','TECH incentive budget updates','https://techcleanca.com/incentives/','Incentive and Rebate Updates')
S('cec_ira','CEC IRA rebate programs','https://www.energy.ca.gov/programs-and-topics/programs/inflation-reduction-act-residential-energy-rebate-programs','HEEHRA PhaseI/II','retrieved; umbrella page contains stale availability language; current administrator reservations control')
S('ebb','CRMP Earthquake Brace+Bolt','https://www.crmp.org/our-seismic-retrofit-programs/the-retrofits/ebb-retrofit','Grant amount; income-eligible supplemental grant; pre1980 raised-foundation eligibility')
S('crmp','CRMP registration','https://www.crmp.org/our-seismic-retrofit-programs/how-to-register','Annual registration / EBB, ESS, EMR')
S('wildfire_discount','CA DOI Safer from Wildfires','https://www.insurance.ca.gov/01-consumers/200-wrr/Safer-from-Wildfires.cfm','10 mitigation actions')
S('wildfire_discount_faq','CA DOI discount FAQ','https://www.insurance.ca.gov/01-consumers/105-type/95-guides/03-res/Insurers-Currently-Offering-Discounts.cfm','How much will my discount be?','exact percentage varies by insurer; no universal rate')
S('mwd','MWD SoCal WaterSmart turf replacement','https://socalwatersmart.com/en/residential/rebates/available-rebates/turf-replacement-program/','General Information; reservation before work')
S('solar_tax','BOE active solar exclusion','https://www.boe.ca.gov/proptaxes/active-solar-energy-system/','New construction exclusion; Jan1 2027 sunset')
S('newconstruction_tax','BOE new-construction exclusions','https://www.boe.ca.gov/proptaxes/newconstructionproperty.htm','R&T73,74.3,74.5 table')
S('ces5','OEHHA CalEnviroScreen5.0','https://oehha.ca.gov/calenviroscreen/report/calenviroscreen-50','July1 2026 release; September18 DAC designation')
S('ces5_catalog','CES5.0 data catalog','https://publish.data.ca.gov/dataset/calenviroscreen-5-0','Data/resources; Oct1–5 2026 updates')
S('dac2026','CalEPA2026 disadvantaged communities designation','https://calepa.ca.gov/programs/dac2026/','Final designation categories; data download')
S('ab8','LA Auditor AB8 allocation factors','https://auditor.lacounty.gov/wp-content/uploads/2026/10/AF91.zip','FY2026–27 AF91','official download link recovered; ZIP contents not parsed')
S('av_tra','LA Auditor assessed value by TRA','https://auditor.lacounty.gov/wp-content/uploads/2026/07/FY26-27-SV11-Mapbook-TRA-Detail.zip','FY2026–27 SV11','official download link recovered; ZIP contents not parsed')
S('tra','BOE LA2026 TRA data','https://boe.ca.gov/maps/LosAngelesCo.htm','Download TRA GIS data')
S('la_verne_ifp','La Verne amended/restated IFP','https://www.laverneca.gov/DocumentCenter/View/3393/La-Verne-Amended-and-Restated-IFP---Approved-by-City-and-County-PDF','printed pp.2,7,13,17–19; PDF pages one lower')
S('la_verne_2018','La Verne2018 county application','https://www.laverneca.gov/DocumentCenter/View/1501/La-Verne-EIFD-County-Application-09-17-18-PDF','printed pp.6–7 fiscal feasibility / preliminary AV projections')
S('la_verne2025','La Verne FY2024–25 annual report','https://www.laverneca.gov/DocumentCenter/View/4221/EIFD-2024---2025-Annual-Report','p.1 A–G')
S('west_carson','West Carson FY2024–25 annual report','https://pw.lacounty.gov/pdd/proj/westcarson-eifd/doc/West-Carson-EIFD-2024_25-Annual-Report-revised.pdf','p.1 B–E')
S('palmdale','Palmdale EIFD official record','https://www.cityofpalmdaleca.gov/1106/Enhanced-Infrastructure-Financing-Distri','IFP; November16 2021 adoption link; $606M/50-year projection')
S('palmdale_ifp','Palmdale IFP','https://www.cityofpalmdaleca.gov/DocumentCenter/View/10672','PDF page NR','download link recovered; PDF too large for retrieval')
S('carson','Carson April2022 redline IFP','https://ci.carson.ca.us/content/files/pdfs/planning/docs/projects/EIFD/Carson%20EIFD%20-%20Infrastructure%20Financing%20Plan%20-%2004.28.22%20%28REDLINE%29.pdf','printed pp.3–4; current adopted final version to reconcile')
S('covina','Covina September2023 adopted IFP','https://covinaca.gov/wp-content/uploads/2025/05/Adopted-Infrastructure-Financing-Plan-and-Boundary-Map1.pdf','pp.3–5 financing; AppendixB acreage; AppendixC revenue projections')
S('covina26','Covina FY2025–26 draft annual report','https://covinaca.gov/wp-content/uploads/2026/09/EIFD-Annual-Report-2025-26-DRAFT.pdf','8-page draft report')
S('placentia','Placentia EIFD official records','https://www.placentia.org/860/Enhanced-Infrastructure-Financing-Distri','AmendedIFP2024; annual reports; base-year version conflict explained')
S('cdiac','State Treasurer CDIAC2024 session5','https://www.treasurer.ca.gov/cdiac/webinars/2024/0522/session_5.pdf','slides103–107 funding and formation; pre-SB1140 hearing process')
S('sb1140','Assembly analysis of SB1140','https://alcl.assembly.ca.gov/system/files/2024-06/sb-1140-caballero.pdf','formation/hearing reforms','primary legislative analysis; final current code controls')
S('gov636','Current GovCode53398.63 primary text mirror','https://codes.findlaw.com/ca/government-code/gov-sect-53398-63/','(d)(5) term alternatives','Jan2026 statutory text mirror; official Leginfo URL returned403')
S('gov666','Current GovCode53398.66 primary text mirror','https://codes.findlaw.com/ca/government-code/gov-sect-53398-66/','(a)–(g) hearings/protests; (j) annual reporting','Jan2026 statutory text mirror; verify subsequent amendments before district formation')
S('ab761','Official Senate AB761 analysis','https://sfa.senate.ca.gov/sites/sfa.senate.ca.gov/files/packet/trp_7.1.24.pdf','AB761 analysis p.2: LA rail/TIFIA75-year exception')
S('sb780','SB7802021 chaptered statutory text','https://legiscan.com/CA/text/SB780/2021','Chapter391; amended sections','primary bill text mirrored; official publisher fetch blocked')
S('metro_esfv','Metro ESFV October19 2026 groundbreaking','https://www.metro.net/about/metro-breaks-ground-on-east-san-fernando-valley-light-rail-transit-project-improving-mobility-throughout-san-fernando-valley/','Funding section: $3.998B construction; $893M federal grant')
S('metro_gateway','Metro Southeast Gateway project','https://www.metro.net/projects/southeastgateway/','Project overview; design stage; estimated2035 completion')
S('speedcam','LADOT Speed Safety System','https://ladot.lacity.gov/speed-safety-system','activation schedule; AB645 requirements;125 sites')
S('percent_art','LA DCA Percent for Public Art','https://culture.lacity.gov/percent-public-art','PWIAP; Private Arts Development Fee')
S('culver_wireless','Culver City wireless utility permits','https://www.culvercity.gov/Services/Building-Development/Wireless-Utility-Permit','Pay Application & Permit Fees; inventory instructions')
S('wireless_la','LA Planning wireless telecommunications','https://planning.lacity.gov/project-review/wireless-telecommunications','Administrative and discretionary filing routes')
S('la_permits26','LA Engineering2026 fee changes','https://engpermits.lacity.org/public/Home/Tools','New fees beginning July1 2026; Ordinance188752')
S('fcc','FCC broadband reference documents','https://help.bdc.fcc.gov/hc/en-us/articles/6789299021723-Key-Reference-Documents','Public Data API specifications; availability downloads')
S('fcc_fabric','FCC Fabric access','https://help.bdc.fcc.gov/hc/en-us/articles/10419121200923-How-Entities-Can-Access-the-Location-Fabric','Steps to Access; CORES/FRN/license required')
S('faa','FAA AAM infrastructure','https://www.faa.gov/airports/new_entrants/aam_infrastructure','Vertiport Design; Parts77/157; EB105A')
S('faa_draft26','FAA October22 2026 draft AC150/5390-4','https://www.faa.gov/regulations_policies/advisory_circulars/index.cfm/go/document.information/documentID/1045778','Draft status; not yet superseding EB105A')
S('shotspotter','NIJ ShotSpotter evaluation','https://nij.ojp.gov/index.php/library/publications/learning-about-shotspotter-and-gun-violence-chicago','Feb1 2024 abstract; study2019-R2-CX-0004')
S('brt_effect','Beaudoin/Tyndall2023 BRT DiD','https://uhero.hawaii.edu/wp-content/uploads/2024/01/UHEROwp2303.pdf','abstract; p.1 transaction panel; regression tables exact estimates below')
S('fiber_effect','Molnar etal. Fiber-or-Fireplace study','https://communitynets.org/sites/www.muninetworks.org/files/2015-06-Fiber-or-Fireplace-Study.pdf','abstract','indexed author paper; full PDF fetch unavailable')
S('solar_value','LBNL2015 Selling Into the Sun','https://energyanalysis.lbl.gov/publications/selling-sun-price-premium-analysis','abstract; report publication2015')
S('brownfield_value','Haninger/Ma/Timmins brownfield study','https://www.nber.org/system/files/working_papers/w20296/w20296.pdf','abstract, revised September2015','indexed abstract; direct PDF returned403')
S('606','DePaul2016 Measuring the Impact of the606','https://www.housingstudies.org/media/filer_public/2016/10/31/ihs_measuring_the_impact_of_the_606.pdf','executive findings; exact table/analytic N/CI NR','indexed original institutional report; descriptive changes are not causal effects')
S('cvv','Zonda/JLC2025 Los Angeles Cost vs Value','https://www.jlconline.com/cost-vs-value/2025/pacific/los-angeles-ca/','named project rows, first geography column = Los Angeles','industry cost/resale estimates D; not measured transaction effects; no bulk CSV recovered')
S('ahsc','SGC AHSC2026 round10','https://sgc.ca.gov/grant-programs/ahsc/','Timeline; application deadline May4 2026; planned awards Dec2026')
S('ahsc_guide','SGC AHSC guidelines','https://sgc.ca.gov/grant-programs/ahsc/guidelines/','Round10 adopted Feb25 2026')
S('tcc','SGC TCC2026 round6','https://sgc.ca.gov/grant-programs/tcc/','Calendar; deadline Sep30 2026; Prop4-funded round')
S('bric','GAO2026 BRIC audit','https://files.gao.gov/reports/GAO-26-107774/index.html','What GAO Found; program restart and March25 2026 combined NOFO')
S('nevi','FHWA August2025 revised NEVI guidance','https://highways.fhwa.dot.gov/newsroom/president-trumps-transportation-secretary-sean-p-duffy-unveils-revised-nevi-guidance','Aug11 2025 guidance release; current individual awards need confirmation')
S('homeless_a','LA County homelessness MeasureA2024','https://homeless.lacounty.gov/measure-a/','Tax replacement date; distribution table')
S('homeless_plan','LA County FY2026–27 spending plan','https://homeless.lacounty.gov/budget-archive/','FY2026–27 $843M departmental plan and funding components')

# Previously recovered specific primary records are retained with their scope
# caveats, not silently relabeled as new awards or current-year unit quotes.
sys.path.insert(0,str(ROOT.parent/'city_pretty_v2/src'))
try:
 from accuracy_rules import COST_RECORDS, SOURCE_IDS
 prior=json.loads((ROOT.parent/'city_pretty_v2/analysis/round2_records.json').read_text())
except (ImportError,FileNotFoundError):
 snapshot=json.loads((ROOT/'legacy_reference.json').read_text())
 COST_RECORDS=snapshot['cost_records'];SOURCE_IDS=snapshot['source_ids'];prior=snapshot['prior_sourcebook_records']
import re
prior_by_id={int(re.match(r'CP2-(\d{3})',r[0]['text']).group(1)):r for r in prior if re.match(r'CP2-(\d{3})',r[0]['text'])}
def prior_source(n):
 id='cp2_'+str(n);r=prior_by_id[n]
 if id not in SOURCES:S(id,r[0]['text'],(r[1]['urls'] or ['NR'])[0],'Prior sourcebook record; '+r[6]['text'],'previously recovered; current live verification NR')
 return id

IMPROVEMENTS=[]
def P(id,name,category,scale='block',maturity='proven',src=(),fits='',data='',negative='',qol='',**kw):
 row={k:'NR' for k in P1};row.update(id=id,name=name,category=category,scale=scale,maturity=maturity,unit='per project; exact scope NR',capex_includes='Full LA project cost NR; design, permitting, land/site control, utility conflicts, labor and contingency require a matched record.',annual_om='NR; no zero-cost assumption',negative_effects=negative or 'Displacement/cost burden, construction disruption and site-specific nuisance require review; measured magnitude NR.',quality_of_life_outcomes=qol or 'Measured numeric outcome NR; no home-price effect inferred from the technology name.',fits_where=fits or 'Actual site/control rights and engineering feasibility must be verified; no automatic block-group suitability from proximity alone.',data_needed_to_site_it=data or 'See Part5 parcel/land-use/ownership and intervention inventory; absence of a mapped asset is not proof of absence.',LA_examples='NR verified opening/full-cost record for this exact intervention',funding_sources='NR pending eligibility screen',sources=cite(*src) if src else 'NR primary intervention-specific source recovered')
 row.update(kw);IMPROVEMENTS.append(row);return row

NAV='https://maps.lacity.org/arcgis/rest/services/Mapping/NavigateLA/MapServer/'
def layer(n):return NAV+str(n)
def B(id,name,category,scale='block',maturity='proven',sources=(),**kw):
 src=[prior_source(x) for x in SOURCE_IDS.get(id,[])]+list(sources)
 row=P(id,name,category,scale,maturity,src=tuple(src),**kw)
 if id in COST_RECORDS:
  num,year,locator,missing,url=COST_RECORDS[id]
  row['capex_per_unit']='NR full cost; comparator: '+num
  row['capex_dollar_year']=year
  row['capex_includes']=missing+' | '+locator
  if isinstance(url,str):row['sources']+=' ; '+url+' | '+locator
 return row

def populate_neighborhoods():
 B('bus_lane','Painted/red bus-only lanes with signs and enforcement','Transit & mobility','corridor',sources=('scw_call',),fits='Existing bus corridor; feasible lane allocation; match actual peak/full-time restriction and service plan. Keep BRT separate.',data=layer(158),qol='FlowerStreet evaluation reports buses up to30% faster; see CP2-049. Home-price coefficient of lanes alone NR.',home_value_effect_pct='NR; do not scale a BRT coefficient',effect_grade='NR',LA_examples='FlowerSt installed2019-06-03; Wilshire2013 budget $31.5M/9.9 corridor-mi; components and current O&M NR; see primary records.')
 B('brt','Full bus rapid transit corridor','Transit & mobility','corridor',sources=('brt_effect',),home_value_effect_pct='5–7 (range across models, NOT a95%CI)',effect_reach_m='NR; study uses20-minute walking network, not a circular radius',effect_grade='B',effect_N='approximately70,000 transactions; model-specific N to recover',effect_study_location='Vancouver, Washington;2017 opening; five-year pre/post panel',negative='Construction, noise, lane reallocation and displacement; transfer to LA requires frequency/accessibility and local controls.')
 for id,name,src in [('light_rail_line','New light rail line',('metro_esfv','metro_gateway')),('rail_station','New/infill light rail station',()),('metrolink_upgrade','Metrolink frequency, track and station upgrades',()),('hsr_station','High-speed/intercity rail station',()),('gondola','Aerial gondola / LA ART proposal',()),('vertiport','Piloted eVTOL vertiport',('faa','faa_draft26'))]:
  B(id,name,'Transit & mobility','regional' if id!='rail_station' else 'district','pre-commercial' if id=='vertiport' else 'pilot' if id=='gondola' else 'proven',sources=src,negative='Noise/downwash or vibration, privacy, displacement, access inequity and operations must be assessed; LA ART/vertiport proposal is not an operating LA value experiment.' if id in ['gondola','vertiport'] else 'Construction, noise/vibration, displacement and station-access barriers; proximity can have negative local effects.')
 # These records verify existence/design routes. Numeric outcomes remain NR until
 # an intervention-specific primary evaluation is recovered.
 for id,name,scale,maturity in [
 ('bus_bulb','Bus-stop bulbs / boarding islands','block','proven'),('transit_signal_priority','Transit signal priority / bus transponders','corridor','proven'),('all_door_boarding','All-door boarding / off-board fare collection','corridor','proven'),
 ('protected_bike','Protected bike lanes','corridor','proven'),('bike_boulevard','Bicycle boulevards / neighborhood greenways','corridor','proven'),('bikeshare','Bikeshare stations','district','proven'),('scooter_corridor','Managed shared e-scooter corridors','corridor','pilot'),('mobility_hub','Mobility hubs / transfers / micromobility parking','block','emerging'),
 ('rails_to_trails','Trails on former rail rights of way','corridor','proven'),('rails_with_trails','Trails alongside active rail','corridor','proven'),('utility_trail','Trails in LADWP/SCE utility corridors','corridor','proven'),('creek_path','River and creek paths','corridor','proven'),
 ('av_service','Autonomous ride-hail service areas (Waymo LA)','district','emerging'),('av_shuttle','Autonomous first/last-mile shuttles','corridor','pilot'),('smart_curb','Smart loading zones / digital curb management','block','emerging'),('congestion_pricing','Congestion pricing / cordon charging','regional','proven'),('parking_cashout','Employer parking cash-out','district','proven'),
 ('road_diet','Road diet with protected cycling space','corridor','proven'),('roundabout','Modern roundabouts / traffic circles','block','proven'),('raised_crosswalk','Raised crosswalks','block','proven'),('lpi','Leading pedestrian intervals','block','proven'),('daylighting','Intersection daylighting / sightline clearance','block','proven'),('school_street','Timed school-street vehicle restrictions','block','pilot')]:
  B(id,name,'Transit & mobility',scale,maturity,data=layer(157)+' ; planned network '+layer(83)+' ; crosswalks '+layer(161),fits='Verify right-of-way, geometry, accessibility and agency authority; match observed trips/crashes and actual installation date. Rails/utility corridors require owner easement and operational clearance; no inference that disused-looking tracks are abandoned.')
 for x in IMPROVEMENTS:
  if x['id'] in ['rails_to_trails','creek_path']:x['sources']+=' ; '+cite('606');x['negative_effects']='Chicago606 institutional report documents strong western-corridor housing appreciation and affordability risk; descriptive changes must not be assigned as a causal trail premium. Exact LA effect/CI/N NR.'
 for id,name,scale,maturity,src in [
 ('small_cell','5G small cells','block','proven',('wireless_la','culver_wireless','la_permits26')),('fiber','Fiber-to-the-home','district','proven',('fiber_effect','fcc')),('public_wifi','Public Wi-Fi','block','proven',('fcc',)),
 ('smart_lighting','LED streetlights with sensors / pedestrian lighting','block','proven',()),('adaptive_signals','Adaptive traffic signals','corridor','proven',()),('ai_traffic','AI-assisted traffic optimization','corridor','emerging',()),('noise_camera','Noise enforcement cameras','block','pilot',()),('speed_camera','AB645 speed safety cameras','corridor','pilot',('speedcam',)),
 ('gunshot_detection','Acoustic gunshot detection (ShotSpotter/SoundThinking)','district','proven',('shotspotter',)),('alpr','Automatic license-plate readers','block','proven',()),('drone_response','Drone-as-first-responder','district','pilot',()),
 ('undergrounding','Power-line undergrounding','corridor','proven',('la_verne_ifp',)),('microgrid','Neighborhood microgrid / resilience hub','block','emerging',()),('vpp','Virtual power plant aggregation','district','emerging',('sgip',)),('neighborhood_battery','Community/neighborhood battery','block','emerging',('sgip',)),('ev_hub','DC fast-charging hub','block','proven',('nevi',)),('curb_ev','Curbside/streetlight charging','block','emerging',()),('v2g','Vehicle-to-grid bidirectional charging','block','pilot',()),
 ('cool_pavement','Cool pavement','corridor','pilot',()),('cool_roof_public','Cool roofs on public buildings','block','proven',()),('shade','Public shade structures','block','proven',()),('cooling_center','Cooling centers / misting','block','proven',()),('permeable_pavement','Permeable pavement','block','proven',('scw_fsg',)),('bioswale','Bioswales / bioretention','block','proven',('scw_fsg',)),('green_street','Stormwater green streets','corridor','proven',('scw_fsg','scw_supp'))]:
  B(id,name,'Streets, safety & energy',scale,maturity,sources=src,data=layer(41)+' ; LADWP overhead '+layer(109)+' ; underground '+layer(110)+' ; safety '+layer(172),negative='Surveillance, retention and discriminatory enforcement risks for sensors/cameras; heat/glare, battery fire, utility conflicts or traffic impacts require intervention-specific assessment. Measured magnitude NR.')
 for x in IMPROVEMENTS:
  if x['id']=='small_cell':x.update(capex_per_unit='NR full build; permit-only: $2,849 utility-pole attachment or $3,429 new/city-pole attachment',capex_dollar_year='current posted schedule; effective year NR',capex_includes='Culver City combined application/permit only; excludes equipment, fiber/power, pole engineering, lease and O&M.',unit='per permit/site')
  if x['id']=='fiber':x.update(home_value_effect_pct=3.1,effect_grade='C',effect_study_location='US national2011–2013 hedonic sample',effect_reach_m='block-group service availability, not distance',effect_N='NR',sources=x['sources']+' ; Combined1.8% speed plus1.3% fiber associations; not two additive interventions or an LA causal coefficient.')
  if x['id']=='speed_camera':x.update(LA_examples='LADOT says first systems activate2026-10-26;125-site rollout by end2026; no completed LA price/crash-effect experiment yet. '+SOURCES['speedcam']['url'],quality_of_life_outcomes='LA measured post-rollout crash/price effect NR; do not import SanFrancisco vendor/early speed percentages as an LA causal result.')
  if x['id']=='gunshot_detection':x.update(quality_of_life_outcomes='NIJ-sponsored matched/synthetic-control study found no reduction in fatal/nonfatal shootings or firearm violent felonies; numeric estimate/CI/N NR.',negative_effects='False/ambiguous alerts, police diversion, surveillance and unequal exposure; shot detection or gun recovery is not a reduction in victimization.')
 for id,name,scale,maturity,src in [
 ('street_trees','Street trees / establishment watering','block','proven',('cityplants',)),('tiny_forest','Miyawaki / tiny urban forest','block','emerging',()),('urban_orchard','Urban public orchards','block','proven',()),('green_roof','Green roofs','block','proven',()),('green_wall','Green walls / vertical forests','block','emerging',()),('creek_daylighting','Creek daylighting / stream restoration','corridor','proven',()),('rain_garden','Rain gardens','block','proven',('scw_fsg',)),('capture_park','Stormwater-capture park / wetland','district','proven',('scw_fsg','scw_trade')),('recycled_irrigation','Recycled-water irrigation','district','proven',()),('public_turf','Turf replacement on public land','block','proven',('mwd',)),
 ('soil_cells','Suspended pavement / Silva Cell soil cells','block','proven',('silva',)),('structural_soil','Structural soil under pavement','block','proven',()),('smart_irrigation','Soil-moisture / weather irrigation sensors','block','proven',('mwd',)),('tree_inventory','Tree inventory and maintenance software','district','proven',()),('urban_carbon','Urban tree carbon projects / City Forest Credits','district','emerging',('cfc',)),('treety','Treety / tree stormwater-financing platform','district','NR',())]:
  B(id,name,'Greening & water',scale,maturity,sources=src,data=layer(59)+' ; parcels/imperviousness/soils, drainage areas and storm-drain network per Part5',fits='Verify ownership/maintenance agreement, soil volume/infiltration, utility clearance and native/climate-appropriate species. Regional MeasureW requires a qualifying stormwater project, not just a tree count.')
 for x in IMPROVEMENTS:
  if x['id']=='soil_cells':x.update(capex_per_unit='14–18 USD/cubic-foot installed (vendor budget range; full project NR)',unit='per cubic foot of soil-cell system',capex_dollar_year='NR',capex_includes='Vendor says excludes base course, final paving and tree; design, land/utilities and contingency NR.',effect_grade='D',effect_study_location='NorthAmerican vendor bid summaries; no LA home-price experiment recovered',sources=cite('silva'))
  if x['id']=='treety':x.update(maturity='NR',sources='NR independently verified public business/product, operating status, fees or MeasureW authorization. User-mentioned name is not evidence of program eligibility.',fits_where='Do not enable an automatic funding match until identity, offered service, terms and program role are verified.',funding_sources='NR; separate verified MeasureW eligibility from company claims')
 for id,name,scale,maturity in [
 ('pocket_park','Pocket park','block','proven'),('freeway_cap','Freeway cap/lid park','regional','proven'),('linear_park','Linear park / greenway','corridor','proven'),('pickleball','Pickleball conversion','block','proven'),('tennis','Public tennis courts','block','proven'),('padel','Padel courts','block','emerging'),('pool','Public swimming pool / aquatic center','district','proven'),('splash_pad','Splash pad','block','proven'),('skate_park','Skate park','block','proven'),('dog_park','Dog park','block','proven'),('adventure_play','Adventure playground','block','proven'),('outdoor_fitness','Outdoor fitness equipment','block','proven'),
 ('public_art','Public art and murals','block','proven'),('cultural_district','Cultural district / cultural facilities','district','proven'),('night_market','Night market','block','proven'),('open_streets','Open streets / CicLAvia','corridor','proven'),('farmers_market','Farmers market','block','proven'),('food_hall','Food hall / small-business incubator','block','proven'),
 ('library','Library renovation and hours','district','proven'),('rec_center','Community/recreation center','district','proven'),('makerspace','Public makerspace','block','proven'),('clinic','Community health clinic','district','proven'),('childcare','Childcare center','block','proven'),('senior_center','Senior center','district','proven'),('resilience_hub','Community resilience hub','block','emerging'),('public_restroom','Accessible public restrooms','block','proven'),('drinking_fountain','Drinking fountains / bottle refill','block','proven'),('schoolyard_green','Schoolyard greening with community access','block','proven'),('community_garden','Community gardens','block','proven')]:
  B(id,name,'Parks, culture & services',scale,maturity,sources=('percent_art',) if id in ['public_art','cultural_district'] else (),fits='Public or secured site rights; verified amenity deficit and community demand; accessible routes, utilities, O&M and noise-sensitive neighbors. Need is not established by a missing OSM feature.')
 for id,name,scale,maturity,src in [
 ('adu','ADUs / JADUs / garage conversions','block','proven',()),('sb9','SB9 lot splits and duplexes','block','proven',()),('sb79','SB79 / TOC transit-oriented zoning','district','proven',()),('missing_middle','Missing-middle infill housing','block','proven',()),('modular','Modular / prefab housing','block','proven',()),('printed_housing','3D-printed housing','block','pilot',()),('adaptive_reuse','Adaptive reuse / office-to-housing','block','proven',()),('clt','Community land trusts','district','proven',()),('affordable_housing','Affordable / LIHTC housing','block','proven',()),('homeownership','Down-payment / shared-equity ownership programs','district','proven',()),('vacant_lot_green','Vacant-lot activation and greening','block','proven',()),('code_enforcement','Code enforcement / nuisance abatement','block','proven',()),('hpoz','Historic/HPOZ designation','district','proven',()),('mills_act','Mills Act preservation contracts','block','proven',()),('blight_rehab','Rehabilitation of blighted homes','block','proven',())]:
  B(id,name,'Housing & land use',scale,maturity,sources=src,data=layer(75)+' ; HPOZ '+layer(79)+' ; nuisance properties '+layer(142)+' ; permits and parcels in Part5',negative='Displacement, construction and rent impacts; appraisal gains need not mean affordability gains. Zoning entitlement, completed housing and owner resale effects are separate treatments.')
 for id,name,scale,maturity,src in [
 ('noise_wall','Conventional sound walls','corridor','proven',()),('transparent_wall','Transparent sound walls','corridor','proven',()),('solar_wall','Solar/PV sound walls','corridor','pilot',()),('vegetation_buffer','Roadside vegetation barriers','corridor','proven',()),('school_filters','Classroom air filtration','block','proven',()),('oil_closure','Oil-well plugging and closure','block','proven',()),('brownfield','Brownfield remediation','block','proven',('brownfield_value',)),('lead_pipe','Lead service-line replacement','block','proven',()),('hardening_zone','Wildfire home-hardening district','district','proven',('wildfire_discount',)),('defensible_space','Defensible-space / Zone0 programs','block','proven',('wildfire_discount',)),('soft_story','Soft-story seismic retrofit','block','proven',('crmp',)),('water_leak','Water leak detection / smart metering','district','proven',()),('sewer_monitor','Smart sewer / storm-drain blockage monitoring','district','emerging',()),('flood_retreat','Floodplain buyouts / managed retreat','block','proven',('bric',))]:
  B(id,name,'Environment & health',scale,maturity,sources=src,data=layer(134)+' ; fire/flood/CES and parcel hazard layers in Part5',negative='Displacement and construction; wall-reflected noise/air trapping, bird strikes for clear barriers, habitat clearance, or altered drainage require treatment-specific design. A noise barrier is not an air-pollution-removal coefficient.')
 for x in IMPROVEMENTS:
  if x['id']=='brownfield':x.update(home_value_effect_pct='5.0–11.5; up to15.2 in alternative matching estimator (not aCI)',effect_grade='B',effect_study_location='US EPA-funded brownfield cleanups; working paper revised2015',effect_CI='NR',effect_N='NR',effect_reach_m='NR exact analysis buffer',sources=cite('brownfield_value'))
  if x['id']=='undergrounding':x['LA_examples']='LaVerne ArrowHighway SCE planning estimate $1,000/linear-ft for approximately1,800ft, IFP2019-dollar project list; not an award or LADWP record. '+SOURCES['la_verne_ifp']['url']+' printed pp.12–13'
  if x['id']=='light_rail_line':x.update(capex_per_unit='NR full resource cost per mile; ESFV2026 construction budget $3.998B (corridor total)',capex_dollar_year=2026,unit='per line / construction phase; isolated station cost NR',capex_includes='Metro describes construction estimate; verify full LOP/land/rolling-stock scope before per-mile comparison. Federal grant $893M is financing, not a cost reduction.',LA_examples='ESFV groundbreaking2026-10-19, not opening; SoutheastGateway in design with estimated2035 opening. '+cite('metro_esfv','metro_gateway'))
  if x['id']=='public_art':x['sources']=cite('percent_art')
  if x['sources'].startswith('NR'):x['maturity']='NR' if x['id']=='treety' else x['maturity'];x['sources']+=' ; Identity/design/price-effect verification outstanding; no coefficient assigned.'

if __name__=='__main__':
 populate_neighborhoods();OUT.mkdir(parents=True,exist_ok=True)
 (OUT/'research_intermediate.json').write_text(json.dumps({'schemas':{'part1':P1,'part2':P2,'part4':P4,'eifd_cases':P3CASE},'part1':IMPROVEMENTS,'sources':list(SOURCES.values())},ensure_ascii=False,indent=2))
 print('Neighborhood rows:',len(IMPROVEMENTS))
