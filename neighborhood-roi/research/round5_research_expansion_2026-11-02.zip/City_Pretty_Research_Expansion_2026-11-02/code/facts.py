"""Scope-matched quantitative evidence and current-policy corrections."""
import math
from data import S,SOURCES,cite,P,B,IMPROVEMENTS,layer

EFFECTS=[]

def wald_log(beta,se):
    return (100*math.expm1(beta),100*math.expm1(beta-1.96*se),100*math.expm1(beta+1.96*se))

def enrich(home,funding):
    S('adu_value24','Brueckner & Thomaz2024, ADUs inLosAngeles','https://onlinelibrary.wiley.com/doi/10.1111/1540-6229.12471','Table7, column4; 2013–2019 just-sold sample; assessor-clustered SE')
    S('gilraine20','Gilraine2020, classroom air filters','https://edworkingpapers.com/sites/default/files/Gilraine_AirFilters_1.pdf','PDFp34 / printedp33 Table3; printedpp23–24 cost-benefit discussion','Author working paper retrieved; not claimed peer-reviewed')
    S('rail_value23','Keeler & Stephens2023, LA Gold/Expo rail capitalization','https://onlinelibrary.wiley.com/doi/10.1111/1540-6229.12411','Abstract; quantitative tables NR','Abstract retrieved; full article/data not recovered; DataQuick data paid/licensed')
    S('gryd21','Brantingham etal.2021 GRYD comprehensive strategy','https://www.tandfonline.com/doi/full/10.1080/24751979.2021.1887709','Results / Table2; full-model Appendix2','Indexed publisher text retrieved; direct full-text403; exact SE/CI NR')
    S('step20','FHWA2020 STEP countermeasures','https://highways.dot.gov/sites/fhwa.dot.gov/files/2022-06/Revised_STEP_Poster_Jan2020_revised_508compliant.pdf','one-page poster; treatment-specific crash outcomes','Historical primary PDF retrieved; ranges are not confidence intervals')
    S('open_streets25','LADOT Metro Open/SlowStreets Cycle6 recommendation','https://cityclerk.lacity.org/onlinedocs/2025/25-1457_rpt_dot_12-04-25.pdf','AttachmentA, WestlakePark-to-Park2026 row; PDF page NR','Primary staff report; proposed local acceptance; final executed agreement NR')
    S('metro_service25','Metro2025 Transit Service Policies and Standards','https://libraryarchives.metro.net/DB_Attachments/Attachment%20B%20%E2%80%93%202025%20Title%20VI%20Program%20Update.pdf','Bus Bulb Outs / Transit Signal Priority; exact PDF page NR')
    S('metro_tsp25','Metro approved countywide cloud TSP contract','https://boardagendas.metro.net/board-report/2025-0045/','2025-0045; Board approved2025-03-27; procurement attachment','Approval recovered; contract price/page NR')
    S('ladot_mobility','LADOT Shared Mobility','https://ladot.lacity.gov/projects/transportation-services/shared-mobility','Mobility Hubs; BlueLA stations reuse')
    S('ladot_curb','LADOT Code the Curb','https://ladot.lacity.gov/codethecurb','Digital curb inventory; no bulk public API recovered')
    S('la_sb79','CityLA local SB79 implementation','https://planning.lacity.gov/resources/senate-bill-sb-79','Local SB79 / Low-Rise ordinances effective2026-06-30; phased implementation')
    S('la_missing_middle26','CityLA Missing Middle LA drafts','https://planning.lacity.gov/node/134566','September2026 ADU/SB9 drafts; drafts are not enacted law')
    S('mural_rule','DCA LA Mural Ordinance','https://culture.lacity.gov/murals','Original Art Mural registration; ordinance adopted2013-10-12')
    S('rails_with','FRA2021 Rails-with-Trails best practices','https://railroads.dot.gov/sites/fra.dot.gov/files/2021-06/Rails%20with%20Trails%20Best%20Practices%20and%20Lessons%20Learned.pdf','Utility and railroad easements / operational clearances; exactpageNR')
    S('treety_identity','Treety in-progress user prototype','https://milessilverman.github.io/treety/','User prior description2026-10-30; USC Tie-hub SHIP Fund work in progress','User-context identity recovered; public URL fetch failed; company/product launch and agency role NR')
    S('la_art26','Metro board LAART EIR decision','https://boardagendas.metro.net/board-report/2025-0953/','Board action2025-12-04; project approval is not opening')
    # Add useful existing-model interventions so every funding reference resolves.
    for id,name,cat in [
        ('bus_shelters','Bus shelters / STAP amenities','Transit & mobility'),
        ('sidewalks','Sidewalk repair and widening','Streets, safety & energy'),
        ('traffic_calming','Speed humps / neighborhood traffic calming','Streets, safety & energy'),
        ('crosswalks','Crosswalk and intersection upgrades','Streets, safety & energy'),
        ('green_alley','Green alley improvements','Greening & water'),
        ('park_upgrade','Park/playground renovation','Parks, culture & services'),
        ('basketball','Basketball courts','Parks, culture & services'),
        ('sports_field','Natural/synthetic sports fields','Parks, culture & services'),
        ('street_lighting','New pedestrian-scale streetlights','Streets, safety & energy'),
        ('cameras','Public security cameras','Streets, safety & energy'),
        ('foot_patrol','Foot patrol staffing','Safety & cleanliness'),
        ('violence_interruption','GRYD comprehensive violence prevention','Safety & cleanliness'),
        ('bid','BID/PBID district management','Safety & cleanliness'),
        ('litter','Litter and illegal-dumping cleanup','Safety & cleanliness'),
        ('graffiti','Graffiti removal','Safety & cleanliness'),
        ('encampment','Housing-first permanent housing and services','Safety & cleanliness'),
        ('grocery','Grocery-store attraction / healthy-food access','Parks, culture & services'),
        ('main_street','Main Street / retail facade revitalization','Parks, culture & services'),
        ('outdoor_dining','Outdoor dining / LA AlFresco','Parks, culture & services')]:
        if not any(x['id']==id for x in IMPROVEMENTS): B(id,name,cat)
    P('public_solar','Public rooftop / parking-lot solar','Streets, safety & energy',src=('irs48','irs_pay'),data=layer(225)+' ; building footprints/roof structure/load and grid interconnection required',fits='Public ownership or lawfulPPA; actual site/structural and interconnection feasibility. Credit eligibility is specific to generation/storage, not cool-roof coating.')
    index={x['id']:x for x in IMPROVEMENTS}
    # Remove a mismatched stormwater citation from the bus lane record.
    index['bus_lane']['sources']=' ; '.join(s for s in index['bus_lane']['sources'].split(' ; ') if not s.startswith('scw_call:'))
    point,lo,hi=wald_log(.053,.008)
    index['brt'].update(home_value_effect_pct=round(point,4),effect_CI=f'{lo:.4f} to{hi:.4f}% approximate95%Wald interval, CALCULATED from rounded logcoef0.053 andSE0.008; not published bootstrap CI',effect_N=27775,effect_reach_m='NR metres; treatment within20-minute network walk, control beyond30-minute walk;20–30minute band omitted',effect_study_location='VancouverWA, TheVine opened2017; paper2023',sources=cite('brt_effect')+' | Table5 col20-minute, PDFp20/printedp19; repeat-sales DiD; other specifications in effect_estimates.csv')
    for id in ['bus_bulb','transit_signal_priority','all_door_boarding']:
        index[id]['sources']+=' ; '+cite('metro_service25','metro_tsp25')
    for id in ['bikeshare','scooter_corridor','mobility_hub','av_shuttle']:
        index[id]['sources']+=' ; '+cite('ladot_mobility')
    index['smart_curb']['sources']=cite('ladot_curb')
    index['gondola']['sources']+=' ; '+cite('la_art26')
    index['gondola']['LA_examples']='LAART EIR Board decision2025-12-04; proposal, not an operating station-value experiment; opening and fullcostNR. '+SOURCES['la_art26']['url']
    index['rail_station']['sources']+=' ; '+cite('rail_value23')
    index['rail_station']['effect_study_location']='Gold/ExpoLines,LosAngeles; peer-reviewed spatialDiD2023; exact coefficient/CI/N NR from accessible abstract'
    index['rail_station']['home_value_effect_pct']='NR; documented heterogeneous effects, no uniform positive LA coefficient recovered'
    index['sb79']['sources']=cite('la_sb79')
    index['sb79']['fits_where']='Use enacted local2026 Low-Rise/phasing ordinances and ZIMAS eligibility, plus current SCAG/HCD maps; CityLA temporarily phasesSB79. Do not mark every transit half-mile eligible from statewide text alone.'
    index['sb9']['sources']+=' ; '+cite('la_missing_middle26')
    index['adu']['sources']+=' ; '+cite('adu_value24')
    index['adu']['home_value_effect_pct']='NR neighboring-home spillover; host parcel association belongs in homeowner module'
    index['treety'].update(maturity='pilot',sources=cite('treety_identity'),fits_where='Identity as user-owned in-progress USC project recovered; fees, deployed service, MeasureW partnership/authority and public operating status NR. Do not infer eligibility from the product name.',funding_sources='NR verified company-administered funding; qualifying stormwater project may apply through actual SCWP programs')
    index['public_art']['sources']+=' ; '+cite('mural_rule')
    index['public_art']['negative_effects']='Gentrification/cultural displacement, removal/maintenance and contested ownership; numeric price/crime/footfall coefficientNR; mural registration is not evidence of a premium.'
    for id in ['rails_with_trails','utility_trail']:
        index[id]['sources']+=' ; '+cite('rails_with')
    for id,outcome in [('road_diet','19–47% fewer total crashes'),('lpi','13% fewer pedestrian crashes'),('crosswalks','23–48% crash reductions across different visibility countermeasures/outcomes')]:
        index[id]['quality_of_life_outcomes']=outcome+'; FHWA2020 poster, historical pooled findings, not a95%CI or LA local causal estimate; N/CI NR.'
        index[id]['sources']+=' ; '+cite('step20')
    index['school_filters'].update(capex_per_unit='About700USD/unit purchase, study-era price; full installed LA bidNR',unit='per portable air-filter unit',capex_dollar_year='NR quote year;2020paper,2016 intervention',capex_includes='Study cost-benefit assumptions, not actual awarded lifecycle cost; annual carbon300USD+electricity24USD/month; filter life5years ASSUMED by author, not observed.',annual_om='NR fullupkeep; study assumes300USD/carbon-replacement/year +24USD/electricity/month in high-cost region; laborNR',lifespan_years='NR observed;5years author cost-benefit assumption',quality_of_life_outcomes='LAUSD2016 spatialRD: math+0.195SD (SE0.064),N4861; English+0.194SD (SE0.082),N4857;28school clusters; wild-bootstrap p0.025/0.096. GradeA for test scores; exact95%bootstrapCI NR. Home-price effectNR.',sources=cite('gilraine20'))
    index['violence_interruption']['quality_of_life_outcomes']='GRYD comprehensive-strategy violent crime ATT−1.07 incidents/reporting-district/quarter; assault−0.56,robbery−0.51; not percent. Sensitive to clustering (bureau-level nonsignificant); no evidence of total-crime reduction. Table2 exactCI/N NR; Appendixfull model820districts×52quarters2005–17 is not main-modelN.'
    index['violence_interruption']['sources']+=' ; '+cite('gryd21')
    index['open_streets']['sources']+=' ; '+cite('open_streets25')
    index['open_streets']['LA_examples']='WestlakePark-to-Park2026 proposed accepted award163611USD +localmatch70119USD =233730USD;2025 staffreport AttachmentA; total event project scope/full resourcecostNR. '+SOURCES['open_streets25']['url']
    # Exactly measured association for the host ADU parcel, with a calculated interval.
    p,l,h=wald_log(.0883,.0125)
    for r in home:
        if r['id'] in ['home_adu','home_jadu','home_garage_adu','home_prefab_adu']:
            r['sources']+=' ; '+cite('adu_value24')
            r['value_source']='Brueckner/Thomaz2024 Table7 col4: laggedADU, blockgroup/yearFE, N75762 just-sold property-years,2013–19; assessor-clusteredSE0.0125; gradeC association. Does not distinguish conversion/JADU/prefab treatment.'
            if r['id']=='home_adu':
                r.update(resale_value_added=f'{p:.4f}% host-parcel association; approximate95%WaldCI[{l:.4f},{h:.4f}] CALCULATED from roundedlogbeta0.0883±1.96×0.0125; not a causal project guarantee',grade='C')
    # Different capital components are not interchangeable for tax credit purposes.
    for f in funding:
        f['eligible_projects']=f['eligible_projects'].replace('cool_roof_public','public_solar') if f['id'] in ['fed48e','solar_ppa','rec_market'] else f['eligible_projects']
        if f['id']=='fed48e': f['eligible_projects']=f['eligible_projects'].replace(';urban_carbon','')
        if f['id']=='scw_trade':
            f['stacking_rules']='INCOMPATIBLE with anySCWP funding at planning/design/construction/O&M stage; municipalities excluded as sellers. Other municipal funding considered case-by-case. No double claim with parcelcredit for same activity. Guidelines printedpp2–5.'
            f['eligible_applicants']='Approved tax-exempt parcel owner/authorized nonmunicipal entity; project must manage runoff from tax-exempt parcels; licensedCAcivilengineerverification'
            f['sources']=cite('scw_trade','scw_trade_receipt','scw_credit')
    funding.append(dict(zip(list(funding[0]),['metro_open','Metro Open and Slow Streets grants','local tax measure','LA Metro','NR recurring annual pool','NR typical; Westlake2026 proposed award163611USD','Example70119USD local match; not generic statutory share','open_streets','Eligible cities/public agencies perCycleguidelines','LA County; actual approved routes','Do not charge the same event invoice to multiple grants; construction and recurring-eventbudgets separate','Cycle6 staffreport2025; next open deadlineNR','program exists; current new application availabilityNR','WestlakePark-to-Park2026,163611USDMetro+70119USDlocal;2025 LADOTreport AttachmentA','Open-streets events can pilot access/public-space changes before permanent capital, with separate evaluation.',cite('open_streets25')])))
    def E(id,intervention,outcome,effect,ci,n,grade,location,reach,source,locator,notes):
        EFFECTS.append(dict(id=id,intervention_id=intervention,outcome=outcome,effect=effect,CI95=ci,N=n,grade=grade,location=location,reach=reach,dollar_year='not monetary' if 'USD' not in effect else 'NR; see source vintage',source_url=SOURCES[source]['url'],page_table=locator,notes=notes))
    for ident,b,se,n,table in [('brt_repeat',.053,.008,27775,'Table5,20-minutecol; PDFp20'),('brt_hedonic',.068,.017,68721,'Table4,20-minutecol; PDFp19')]:
        p,l,h=wald_log(b,se)
        E(ident,'brt','saleprice',f'{p:.4f}% =100×expm1({b})',f'[{l:.4f},{h:.4f}]% approximateWald CALCULATED from roundedSE{se}',n,'B','VancouverWA,2017TheVine opening; paper2023','20-minute network walk; control>30minutes','brt_effect',table,'Models are alternatives, not additive; two-way clusteredSE; no precise full-effect timing recovered.')
    E('adu_host','adu','host-parcel saleprice',f'{100*math.expm1(.0883):.4f}% association',f'[{100*math.expm1(.0883-1.96*.0125):.4f},{100*math.expm1(.0883+1.96*.0125):.4f}]% approximateWald CALCULATED',75762,'C','CityLosAngeles2013–19','hostparcel only','adu_value24','Table7col4','LaggedADU/blockgroup+yearFE; neither neighboring-spillover nor randomized construction effect.')
    E('filter_math','school_filters','mathscore','+0.195SD','NR exactwild-bootstrap interval; SE0.064; p0.025',4861,'A','LAUSD,AlisoCanyon2016','Schools near5-mile treatmentthreshold;1.75mileRDbandwidth, not ambient benefitradius','gilraine20','printedp33/PDFp34 Table3col3','28schoolclusters; inference from wildbootstrap, so normalCI not substituted. Price effectNR.')
    E('filter_english','school_filters','Englishscore','+0.194SD','NR exactwild-bootstrap interval; SE0.082; p0.096',4857,'A','LAUSD,AlisoCanyon2016','Schools near5-mile treatmentthreshold;1.75mileRDbandwidth','gilraine20','printedp33/PDFp34 Table3col3','Not statistically significant at5% with authors preferredwildbootstrap; do not describe bothsubjects as significant.')
    E('gryd_violent','violence_interruption','violentcrime','−1.07incidents/reportingdistrict/quarter','NR; significance sensitive to clustering','NR main-model N; full alternative820RD×52quarters','A','CityLA2005–17','servedreportingdistrict; no measured spillover benefit','gryd21','Results/Table2','Comprehensive strategy, not one outreach team; no total-crime reduction demonstrated. No percent conversion without baseline.')
    E('solar_owned','public_solar','owner-home saleprice','About4USD/W ownedPV premium','NR','22822sales;3951PVhomes','C','8USstates2002–13;report2015','hostproperty','solar_value','Abstract','Homeowner evidence does not measure neighborhoodspillover from a publicsolarcarport; currentmarketpremiumNR.')
    return EFFECTS
